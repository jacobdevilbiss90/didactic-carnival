import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Settings, c as Layers, d as Check, i as Swords, l as Copy, n as Users, o as ScrollText, s as Plus, t as X, u as Compass } from "../_libs/lucide-react.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { n as persist, r as create, t as createJSONStorage } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DbzzwAZY.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Button({ variant = "ghost", className, type = "button", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type,
		className: clsx("press inline-flex h-11 items-center justify-center gap-2 rounded-sm px-3 text-sm font-medium disabled:opacity-40", variant === "primary" && "bg-accent text-accent-fg", variant === "ghost" && "border border-line bg-raised text-fg", variant === "quiet" && "bg-transparent text-muted", variant === "danger" && "border border-line bg-raised text-danger", className),
		...props
	});
}
var controlClass = "h-11 w-full rounded-sm border border-line bg-bg px-3 text-sm text-fg outline-none placeholder:text-faint";
var areaClass = "min-h-24 w-full rounded-md border border-line bg-bg px-3 py-2 text-sm text-fg outline-none placeholder:text-faint";
function Field({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "mb-3 block",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "mb-1 block text-xs font-medium text-muted",
			children: label
		}), children]
	});
}
function ViewHeader({ kicker, title, action }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "mb-5 flex items-end justify-between gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-0",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium text-faint",
				children: kicker
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "truncate text-xl font-semibold tracking-tight text-fg",
				children: title
			})]
		}), action]
	});
}
function Card({ children, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: clsx("rounded-xl border border-line bg-surface p-4", className),
		children
	});
}
function Sheet({ open, title, onClose, children }) {
	const ref = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		if (!open) return;
		const onKey = (e) => {
			if (e.key === "Escape") onClose();
		};
		window.addEventListener("keydown", onKey);
		ref.current?.querySelector("input, select, textarea")?.focus();
		return () => window.removeEventListener("keydown", onKey);
	}, [open, onClose]);
	if (!open) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fixed inset-0 z-40 flex items-end justify-center md:items-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "absolute inset-0 bg-scrim",
			"aria-label": "Close dialog",
			onClick: onClose
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			ref,
			role: "dialog",
			"aria-modal": "true",
			"aria-label": title,
			className: "sheet relative z-10 max-h-[85vh] w-full overflow-y-auto rounded-t-xl border border-line bg-surface p-4 md:max-w-md md:rounded-xl",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-4 flex items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-lg font-semibold tracking-tight",
					children: title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: onClose,
					className: "w-11 px-0",
					"aria-label": "Close",
					variant: "quiet",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { size: 18 })
				})]
			}), children]
		})]
	});
}
function Segment({ value, options, onChange, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		role: "tablist",
		"aria-label": label,
		className: "mb-4 grid gap-1 rounded-lg bg-surface p-1",
		style: { gridTemplateColumns: `repeat(${options.length}, minmax(0, 1fr))` },
		children: options.map((opt) => {
			const on = opt.id === value;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				role: "tab",
				"aria-selected": on,
				onClick: () => onChange(opt.id),
				className: clsx("press h-11 rounded-md text-sm font-medium", on ? "bg-raised text-fg" : "text-muted"),
				children: opt.label
			}, opt.id);
		})
	});
}
var RANKS = [
	"R5",
	"R4",
	"R3",
	"R2",
	"R1"
];
var ROLES = [
	{
		id: "member",
		label: "Member"
	},
	{
		id: "captain",
		label: "Rally captain"
	},
	{
		id: "builder",
		label: "Builder"
	},
	{
		id: "farm",
		label: "Farm"
	}
];
var PRESENCE = [
	{
		id: "active",
		label: "Active"
	},
	{
		id: "away",
		label: "Away"
	},
	{
		id: "inactive",
		label: "Review"
	}
];
var PHASES = [
	{
		id: "early",
		label: "Early",
		hint: "Levels 1–5. Capacity and help first."
	},
	{
		id: "growth",
		label: "Growth",
		hint: "Levels 6–8. Cover nodes, then rally size."
	},
	{
		id: "mature",
		label: "Mature",
		hint: "Levels 9–11. Battle tech and fortresses."
	}
];
var KIND_INFO = {
	bear: {
		label: "Bear Hunt",
		cadence: "Every 2 server days",
		rule: "R4 or R5 arms the trap. Only the rally starter can kick or disband a bear rally."
	},
	"crazy-joe": {
		label: "Crazy Joe",
		cadence: "Defense rotation",
		rule: "Unshielded in the hive. Reinforce thinner cities before the first wave."
	},
	mobilization: {
		label: "Alliance Mobilization",
		cadence: "Weekly, Monday to Sunday",
		rule: "Refresh a weak mission before you claim it. An open slot all day is wasted points."
	},
	fortress: {
		label: "Fortress Battle",
		cadence: "Fridays, 2-hour window",
		rule: "Hold for 30 minutes to capture. Prefer targets near the HQ."
	},
	foundry: {
		label: "Foundry Battle",
		cadence: "Registration window",
		rule: "Lock the time slot and the starter list before registration closes."
	},
	championship: {
		label: "Alliance Championship",
		cadence: "Season rounds",
		rule: "Three lanes. Put online power in mid, and do not leave a lane empty."
	},
	svs: {
		label: "State vs State",
		cadence: "Season battle",
		rule: "Hospital, shields, and rally captains published before the hit window."
	},
	showdown: {
		label: "Alliance Showdown",
		cadence: "Weekly scoring",
		rule: "Clear the alliance floor. Small accounts still move the total."
	},
	custom: {
		label: "Custom",
		cadence: "One-off",
		rule: ""
	}
};
var TREE_LABEL = {
	growth: "Growth",
	territory: "Territory",
	battle: "Battle"
};
var PHASE_ORDER = {
	early: [
		"capacity",
		"help-count",
		"help-time",
		"build-speed"
	],
	growth: [
		"banners",
		"nodes",
		"rally-size",
		"warehouse"
	],
	mature: [
		"troop-atk",
		"beast",
		"troop-def",
		"march"
	]
};
var PHASE_WHY = {
	early: "Capacity and help pay back every day. Battle tech can wait.",
	growth: "Nodes only pay once territory covers them. Finish banners before battle tech.",
	mature: "Growth is online. Attack, beast damage, and march speed move rallies and forts."
};
var FORT_STATUS = [
	{
		id: "open",
		label: "Open"
	},
	{
		id: "target",
		label: "Target"
	},
	{
		id: "held",
		label: "Held"
	},
	{
		id: "enemy",
		label: "Enemy"
	}
];
var RALLY_STATUS = [
	"forming",
	"locked",
	"done"
];
function atHour(base, dayOffset, hour) {
	const d = new Date(base);
	d.setDate(d.getDate() + dayOffset);
	d.setHours(hour, 0, 0, 0);
	return d.getTime();
}
function nextWeekday(base, weekday, hour) {
	const d = new Date(base);
	let delta = (weekday - d.getDay() + 7) % 7;
	if (delta === 0 && d.getHours() >= hour) delta = 7;
	d.setDate(d.getDate() + delta);
	d.setHours(hour, 0, 0, 0);
	return d.getTime();
}
function startOfWeek(base) {
	const d = new Date(base);
	const delta = (d.getDay() + 6) % 7;
	d.setDate(d.getDate() - delta);
	d.setHours(0, 0, 0, 0);
	return d;
}
function defaultStart(kind, now = Date.now()) {
	const base = new Date(now);
	if (kind === "fortress") return nextWeekday(base, 5, 20);
	if (kind === "mobilization") return startOfWeek(base).getTime();
	if (kind === "championship") return atHour(base, 4, 19);
	return atHour(base, 1, 19);
}
function initial(now = Date.now()) {
	const base = new Date(now);
	const bearAt = base.getHours() < 19 ? atHour(base, 0, 19) : atHour(base, 1, 19);
	const members = [
		{
			id: "veyra",
			name: "Veyra",
			rank: "R5",
			power: 1624e5,
			furnace: 30,
			role: "captain",
			presence: "active",
			note: "Calls fort targets."
		},
		{
			id: "kestrel",
			name: "Kestrel",
			rank: "R4",
			power: 1481e5,
			furnace: 30,
			role: "captain",
			presence: "active",
			note: "Bear starter tonight."
		},
		{
			id: "ironmoth",
			name: "Ironmoth",
			rank: "R4",
			power: 139e6,
			furnace: 29,
			role: "captain",
			presence: "active",
			note: "Terror rallies."
		},
		{
			id: "sable",
			name: "Sable",
			rank: "R4",
			power: 1216e5,
			furnace: 28,
			role: "builder",
			presence: "active",
			note: "Banner lead."
		},
		{
			id: "holt",
			name: "Holt",
			rank: "R3",
			power: 984e5,
			furnace: 27,
			role: "captain",
			presence: "active",
			note: ""
		},
		{
			id: "marrow",
			name: "Marrow",
			rank: "R3",
			power: 912e5,
			furnace: 27,
			role: "member",
			presence: "active",
			note: ""
		},
		{
			id: "pike",
			name: "Pike",
			rank: "R3",
			power: 88e6,
			furnace: 26,
			role: "member",
			presence: "active",
			note: ""
		},
		{
			id: "nera",
			name: "Nera",
			rank: "R2",
			power: 765e5,
			furnace: 26,
			role: "member",
			presence: "active",
			note: ""
		},
		{
			id: "quinn",
			name: "Quinn",
			rank: "R2",
			power: 741e5,
			furnace: 25,
			role: "member",
			presence: "away",
			note: "Travel until Friday."
		},
		{
			id: "ashfen",
			name: "Ashfen",
			rank: "R2",
			power: 708e5,
			furnace: 25,
			role: "farm",
			presence: "active",
			note: "Joins bear if online."
		},
		{
			id: "bramble",
			name: "Bramble",
			rank: "R2",
			power: 664e5,
			furnace: 24,
			role: "member",
			presence: "active",
			note: ""
		},
		{
			id: "joss",
			name: "Joss",
			rank: "R2",
			power: 639e5,
			furnace: 25,
			role: "member",
			presence: "active",
			note: ""
		},
		{
			id: "torv",
			name: "Torv",
			rank: "R1",
			power: 582e5,
			furnace: 24,
			role: "member",
			presence: "active",
			note: ""
		},
		{
			id: "lumen",
			name: "Lumen",
			rank: "R1",
			power: 54e6,
			furnace: 23,
			role: "member",
			presence: "away",
			note: ""
		},
		{
			id: "cade",
			name: "Cade",
			rank: "R1",
			power: 497e5,
			furnace: 22,
			role: "member",
			presence: "inactive",
			note: "Missed the last two bears."
		},
		{
			id: "yarrow",
			name: "Yarrow",
			rank: "R1",
			power: 413e5,
			furnace: 21,
			role: "farm",
			presence: "inactive",
			note: "Farm. Shield on SvS day."
		}
	];
	const inIds = [
		"veyra",
		"kestrel",
		"ironmoth",
		"sable",
		"holt",
		"marrow",
		"pike",
		"nera",
		"bramble",
		"joss"
	];
	const bearRsvp = {};
	for (const id of inIds) bearRsvp[id] = "in";
	bearRsvp.quinn = "out";
	bearRsvp.ashfen = "maybe";
	return {
		alliance: {
			name: "Northwatch",
			tag: "NWT",
			server: "214",
			level: 8,
			phase: "growth",
			cap: 70,
			donations: 18400,
			donationGoal: 25e3,
			bearLevel: 6,
			ordersNote: "Hive on the north banners. No solo hits on NAP tags."
		},
		members,
		events: [
			{
				id: "bear",
				kind: "bear",
				title: "Bear Hunt",
				startsAt: bearAt,
				note: "Online 10 minutes early. First slot is your best expedition skill.",
				rsvp: bearRsvp
			},
			{
				id: "mob",
				kind: "mobilization",
				title: "Alliance Mobilization",
				startsAt: startOfWeek(base).getTime(),
				note: "Today's focus: training and rallies. Refresh 1-star missions.",
				rsvp: {}
			},
			{
				id: "joe",
				kind: "crazy-joe",
				title: "Crazy Joe",
				startsAt: atHour(base, 2, 18),
				note: "Garrison the sub-FC25 cities first.",
				rsvp: {}
			},
			{
				id: "fort",
				kind: "fortress",
				title: "Fortress Battle",
				startsAt: nextWeekday(base, 5, 20),
				note: "Weapon IV and Expedition III. Hold 30 minutes.",
				rsvp: {
					veyra: "in",
					kestrel: "in",
					ironmoth: "in",
					sable: "in",
					holt: "in"
				}
			},
			{
				id: "champ",
				kind: "championship",
				title: "Alliance Championship",
				startsAt: atHour(base, 4, 19),
				note: "Lane lock an hour before open.",
				rsvp: {
					veyra: "in",
					kestrel: "in",
					ironmoth: "in",
					sable: "in",
					holt: "in",
					marrow: "in",
					pike: "in",
					nera: "maybe"
				},
				lanes: {
					mid: ["veyra", "kestrel"],
					left: ["ironmoth", "holt"],
					right: ["sable"]
				}
			}
		],
		rallies: [{
			id: "rally-bear",
			target: "Bear",
			captainId: "kestrel",
			startsAt: bearAt + 3e5,
			slots: 8,
			filled: 5,
			hero: "Jessie, first slot",
			status: "forming"
		}, {
			id: "rally-terror",
			target: "Polar Terror 7",
			captainId: "ironmoth",
			startsAt: atHour(base, 0, Math.min(23, base.getHours() + 2)),
			slots: 8,
			filled: 8,
			hero: "Bahiti, first slot",
			status: "locked"
		}],
		tech: [
			{
				id: "capacity",
				tree: "growth",
				name: "Member capacity",
				effect: "Raises the roster cap.",
				level: 4,
				max: 5
			},
			{
				id: "help-count",
				tree: "growth",
				name: "Help requests",
				effect: "More helps on each timer.",
				level: 5,
				max: 5
			},
			{
				id: "help-time",
				tree: "growth",
				name: "Help duration",
				effect: "Each help cuts more time.",
				level: 3,
				max: 5
			},
			{
				id: "build-speed",
				tree: "growth",
				name: "Construction speed",
				effect: "Faster alliance builds.",
				level: 4,
				max: 8
			},
			{
				id: "research-speed",
				tree: "growth",
				name: "Research speed",
				effect: "Faster personal research for members.",
				level: 3,
				max: 8
			},
			{
				id: "banners",
				tree: "territory",
				name: "Banner count",
				effect: "More banners, wider hive.",
				level: 4,
				max: 5
			},
			{
				id: "nodes",
				tree: "territory",
				name: "Node output",
				effect: "Territory nodes feed the warehouse.",
				level: 2,
				max: 6
			},
			{
				id: "warehouse",
				tree: "territory",
				name: "Warehouse",
				effect: "Larger alliance stockpile.",
				level: 2,
				max: 5
			},
			{
				id: "expand",
				tree: "territory",
				name: "Expansion speed",
				effect: "Banners finish faster.",
				level: 1,
				max: 5
			},
			{
				id: "rally-size",
				tree: "battle",
				name: "Rally slots",
				effect: "More marches in each rally.",
				level: 3,
				max: 6
			},
			{
				id: "troop-atk",
				tree: "battle",
				name: "Troop attack",
				effect: "Alliance attack bonus.",
				level: 2,
				max: 10
			},
			{
				id: "troop-def",
				tree: "battle",
				name: "Troop defense",
				effect: "Alliance defense bonus.",
				level: 2,
				max: 10
			},
			{
				id: "beast",
				tree: "battle",
				name: "Beast damage",
				effect: "Rally damage against terrors and the bear.",
				level: 1,
				max: 8
			},
			{
				id: "march",
				tree: "battle",
				name: "March speed",
				effect: "Faster marches for members.",
				level: 2,
				max: 8
			}
		],
		forts: [
			{
				id: "con1",
				name: "Construction I",
				buff: "Construction speed +5%",
				status: "open"
			},
			{
				id: "con3",
				name: "Construction III",
				buff: "Construction speed +8%",
				status: "open"
			},
			{
				id: "def2",
				name: "Defense II",
				buff: "Troop defense +5%",
				status: "open"
			},
			{
				id: "def4",
				name: "Defense IV",
				buff: "Troop defense +8%",
				status: "enemy"
			},
			{
				id: "tech1",
				name: "Tech I",
				buff: "Research speed +5%",
				status: "held"
			},
			{
				id: "tech3",
				name: "Tech III",
				buff: "Research speed +8%",
				status: "open"
			},
			{
				id: "wep2",
				name: "Weapon II",
				buff: "Troop attack +5%",
				status: "open"
			},
			{
				id: "wep4",
				name: "Weapon IV",
				buff: "Troop attack +8%",
				status: "target"
			},
			{
				id: "gath",
				name: "Gathering I",
				buff: "Gathering speed +5%",
				status: "held"
			},
			{
				id: "prod",
				name: "Production I",
				buff: "Production speed +5%",
				status: "open"
			},
			{
				id: "train",
				name: "Training II",
				buff: "Training speed +5%",
				status: "open"
			},
			{
				id: "exp",
				name: "Expedition III",
				buff: "March speed +15%",
				status: "target"
			}
		],
		duties: [
			{
				id: "bear-post",
				label: "Bear time posted in chat",
				done: false
			},
			{
				id: "mob-focus",
				label: "Mobilization focus announced",
				done: true
			},
			{
				id: "tech-mark",
				label: "Priority tech marked, started if the bar is full",
				done: false
			},
			{
				id: "inactive",
				label: "Inactive names reviewed",
				done: false
			},
			{
				id: "fort-reg",
				label: "Fortress targets registered",
				done: true
			},
			{
				id: "captains",
				label: "Rally captain list is current",
				done: false
			}
		]
	};
}
function formatPower(n) {
	if (!Number.isFinite(n) || n <= 0) return "0";
	if (n >= 1e6) {
		const m = n / 1e6;
		return `${m >= 100 ? m.toFixed(0) : m.toFixed(1)}M`;
	}
	if (n >= 1e3) return `${Math.round(n / 1e3)}K`;
	return String(Math.round(n));
}
function formatWhen(ts, now = Date.now()) {
	const d = new Date(ts);
	const start = new Date(now);
	start.setHours(0, 0, 0, 0);
	const day = new Date(ts);
	day.setHours(0, 0, 0, 0);
	const diff = Math.round((day.getTime() - start.getTime()) / 864e5);
	const hm = d.toLocaleTimeString([], {
		hour: "numeric",
		minute: "2-digit"
	});
	if (diff === 0) return `Today ${hm}`;
	if (diff === 1) return `Tomorrow ${hm}`;
	if (diff === -1) return `Yesterday ${hm}`;
	if (diff > 1 && diff < 7) return `${d.toLocaleDateString([], { weekday: "short" })} ${hm}`;
	return `${d.toLocaleDateString([], {
		month: "short",
		day: "numeric"
	})} ${hm}`;
}
function formatCountdown(ts, now) {
	const delta = ts - now;
	const minutes = Math.max(0, Math.round(Math.abs(delta) / 6e4));
	const h = Math.floor(minutes / 60);
	const m = minutes % 60;
	const body = h > 48 ? `${Math.round(h / 24)}d` : h > 0 ? `${h}h ${m}m` : `${m}m`;
	if (Math.abs(delta) < 3e4) return "now";
	return delta >= 0 ? `in ${body}` : `${body} ago`;
}
function formatStamp(now = Date.now()) {
	return new Date(now).toLocaleDateString([], {
		weekday: "short",
		month: "short",
		day: "numeric"
	});
}
function toLocalInput(ts) {
	const d = new Date(ts);
	const pad = (n) => String(n).padStart(2, "0");
	return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}
function fromLocalInput(value) {
	const t = new Date(value).getTime();
	return Number.isFinite(t) ? t : Date.now();
}
function sortedMembers(members) {
	const rank = {
		R5: 0,
		R4: 1,
		R3: 2,
		R2: 3,
		R1: 4
	};
	return [...members].sort((a, b) => rank[a.rank] - rank[b.rank] || b.power - a.power);
}
function memberById(members, id) {
	return members.find((m) => m.id === id);
}
function memberName(members, id) {
	return memberById(members, id)?.name ?? "Unassigned";
}
function nextEvent(events, now) {
	const sorted = [...events].sort((a, b) => a.startsAt - b.startsAt);
	return sorted.find((e) => e.startsAt >= now - 18e5) ?? sorted[0] ?? null;
}
function rsvpCounts(event, members) {
	let inn = 0;
	let out = 0;
	let maybe = 0;
	let silent = 0;
	for (const m of members) {
		const v = event.rsvp[m.id];
		if (v === "in") inn += 1;
		else if (v === "out") out += 1;
		else if (v === "maybe") maybe += 1;
		else silent += 1;
	}
	return {
		inn,
		out,
		maybe,
		silent
	};
}
function namesFor(event, members, value) {
	return sortedMembers(members).filter((m) => value === "silent" ? !event.rsvp[m.id] : event.rsvp[m.id] === value).map((m) => m.name);
}
function recommendation(tech, phase) {
	for (const id of PHASE_ORDER[phase]) {
		const node = tech.find((t) => t.id === id);
		if (node && node.level < node.max) return {
			node,
			why: PHASE_WHY[phase]
		};
	}
	const fallback = tech.find((t) => t.level < t.max) ?? null;
	return {
		node: fallback,
		why: fallback ? "Marked priorities for this phase are done. This is the next open node." : "Every tracked node is finished."
	};
}
function treeProgress(tech, tree) {
	const list = tech.filter((t) => t.tree === tree);
	const cur = list.reduce((sum, n) => sum + n.level, 0);
	const max = list.reduce((sum, n) => sum + n.max, 0);
	return {
		cur,
		max,
		pct: max ? Math.round(cur / max * 100) : 0
	};
}
function emptyLanes() {
	return {
		left: [],
		mid: [],
		right: []
	};
}
function cycleLane(lanes, memberId) {
	const current = lanes ?? emptyLanes();
	const cleaned = {
		left: current.left.filter((id) => id !== memberId),
		mid: current.mid.filter((id) => id !== memberId),
		right: current.right.filter((id) => id !== memberId)
	};
	const spot = current.mid.includes(memberId) ? "left" : current.left.includes(memberId) ? "right" : current.right.includes(memberId) ? null : "mid";
	if (spot) cleaned[spot].push(memberId);
	return cleaned;
}
function balanceLanes(event, members) {
	const lanes = emptyLanes();
	const ranked = sortedMembers(members).filter((m) => event.rsvp[m.id] === "in").sort((a, b) => b.power - a.power);
	const order = [
		"mid",
		"left",
		"right",
		"right",
		"left",
		"mid"
	];
	ranked.forEach((m, i) => {
		lanes[order[i % order.length]].push(m.id);
	});
	return lanes;
}
function join(names) {
	return names.length ? names.join(", ") : "none";
}
function buildPing(kind, data, now = Date.now()) {
	const { alliance, members, events, rallies, tech, forts } = data;
	const head = `[${alliance.tag}] ${alliance.name}`;
	const upcoming = nextEvent(events, now);
	const rec = recommendation(tech, alliance.phase);
	const targets = forts.filter((f) => f.status === "target");
	const held = forts.filter((f) => f.status === "held");
	const review = members.filter((m) => m.presence === "inactive");
	const bear = events.find((e) => e.kind === "bear") ?? upcoming;
	const champ = events.find((e) => e.kind === "championship");
	if (kind === "bear") {
		if (!bear) return {
			title: "Bear call",
			body: `${head}\nNo bear on the board. Add one under Ops.`
		};
		const c = rsvpCounts(bear, members);
		return {
			title: "Bear call",
			body: [
				`${head} — ${bear.title}`,
				`${formatWhen(bear.startsAt, now)} (${formatCountdown(bear.startsAt, now)})`,
				`Trap level ${alliance.bearLevel}. Online 10 minutes early.`,
				`In (${c.inn}): ${join(namesFor(bear, members, "in"))}`,
				`Out: ${join(namesFor(bear, members, "out"))}`,
				`Maybe: ${join(namesFor(bear, members, "maybe"))}`,
				`No reply: ${join(namesFor(bear, members, "silent"))}`,
				KIND_INFO.bear.rule,
				bear.note
			].filter(Boolean).join("\n")
		};
	}
	if (kind === "silent") {
		if (!upcoming) return {
			title: "Silent nudge",
			body: `${head}\nNothing scheduled to chase.`
		};
		return {
			title: "Silent nudge",
			body: [
				`${head} — need a yes or no`,
				`${upcoming.title} · ${formatWhen(upcoming.startsAt, now)}`,
				join(namesFor(upcoming, members, "silent")),
				"Reply in alliance chat. Silence gets read as inactive."
			].join("\n")
		};
	}
	if (kind === "donate") {
		const node = rec.node;
		return {
			title: "Donate ping",
			body: [
				`${head} — tech donations`,
				node ? `Next: ${node.name} ${node.level}/${node.max}. ${node.effect}` : "No open research.",
				`Today ${alliance.donations.toLocaleString()} / ${alliance.donationGoal.toLocaleString()}.`,
				"Resources before gems. Do not start a side tech.",
				rec.why
			].join("\n")
		};
	}
	if (kind === "forts") return {
		title: "Fortress plan",
		body: [
			`${head} — fortresses`,
			targets.length ? `Targets: ${targets.map((f) => `${f.name} (${f.buff})`).join("; ")}` : "No targets marked.",
			held.length ? `Already held: ${held.map((f) => f.name).join(", ")}` : "Nothing held.",
			KIND_INFO.fortress.rule
		].join("\n")
	};
	if (kind === "lanes") {
		if (!champ) return {
			title: "Lane card",
			body: `${head}\nNo championship on the board.`
		};
		const lanes = champ.lanes ?? emptyLanes();
		const line = (key) => `${key[0].toUpperCase()}${key.slice(1)}: ${join(lanes[key].map((id) => memberName(members, id)))}`;
		const assigned = /* @__PURE__ */ new Set([
			...lanes.left,
			...lanes.mid,
			...lanes.right
		]);
		const loose = namesFor(champ, members, "in").filter((name) => {
			const m = members.find((x) => x.name === name);
			return m ? !assigned.has(m.id) : false;
		});
		return {
			title: "Lane card",
			body: [
				`${head} — ${champ.title}`,
				formatWhen(champ.startsAt, now),
				line("mid"),
				line("left"),
				line("right"),
				`In, no lane: ${join(loose)}`,
				KIND_INFO.championship.rule
			].join("\n")
		};
	}
	const lines = [
		`${head} · State ${alliance.server} · Lv.${alliance.level}`,
		`Orders · ${formatStamp(now)}`,
		""
	];
	if (upcoming) {
		const c = rsvpCounts(upcoming, members);
		lines.push(`NEXT — ${upcoming.title}`, `${formatWhen(upcoming.startsAt, now)} (${formatCountdown(upcoming.startsAt, now)})`, KIND_INFO[upcoming.kind].rule, upcoming.note, `In ${c.inn} · Out ${c.out} · Maybe ${c.maybe} · Silent ${c.silent}`, c.silent ? `No reply: ${join(namesFor(upcoming, members, "silent"))}` : "Everyone has answered.", "");
	}
	const openRallies = rallies.filter((r) => r.status !== "done");
	if (openRallies.length) {
		lines.push("RALLIES");
		for (const r of openRallies) lines.push(`${r.target} · ${memberName(members, r.captainId)} · ${r.status} · ${r.filled}/${r.slots} · ${formatWhen(r.startsAt, now)}`, r.hero ? `First slot: ${r.hero}` : "Set the first-slot hero.");
		lines.push("");
	}
	if (rec.node) lines.push("RESEARCH", `${rec.node.name} ${rec.node.level}/${rec.node.max}`, `Donations ${alliance.donations.toLocaleString()} / ${alliance.donationGoal.toLocaleString()} today.`, "");
	if (targets.length) lines.push("FORTRESS TARGETS", targets.map((f) => `${f.name} — ${f.buff}`).join("\n"), "");
	if (review.length) lines.push("ROSTER REVIEW", review.map((m) => `${m.name}${m.note ? ` — ${m.note}` : ""}`).join("\n"), "");
	if (alliance.ordersNote.trim()) lines.push("NOTE", alliance.ordersNote.trim());
	return {
		title: "Full orders",
		body: lines.join("\n").trim()
	};
}
function isRecord(v) {
	return !!v && typeof v === "object" && !Array.isArray(v);
}
function normalizeDesk(raw) {
	if (!isRecord(raw) || !isRecord(raw.alliance) || !Array.isArray(raw.members)) return null;
	const base = initial();
	const alliance = { ...base.alliance };
	const src = raw.alliance;
	if (typeof src.name === "string" && src.name.trim()) alliance.name = src.name.trim().slice(0, 40);
	if (typeof src.tag === "string") alliance.tag = src.tag.trim().slice(0, 6) || alliance.tag;
	if (typeof src.server === "string") alliance.server = src.server.trim().slice(0, 12);
	if (typeof src.level === "number") alliance.level = clamp(src.level, 1, 11);
	if (src.phase === "early" || src.phase === "growth" || src.phase === "mature") alliance.phase = src.phase;
	if (typeof src.cap === "number") alliance.cap = clamp(src.cap, 10, 120);
	if (typeof src.donations === "number") alliance.donations = Math.max(0, Math.round(src.donations));
	if (typeof src.donationGoal === "number") alliance.donationGoal = Math.max(0, Math.round(src.donationGoal));
	if (typeof src.bearLevel === "number") alliance.bearLevel = clamp(src.bearLevel, 1, 20);
	if (typeof src.ordersNote === "string") alliance.ordersNote = src.ordersNote.slice(0, 400);
	const members = raw.members.filter(isMember);
	if (!members.length) return null;
	return {
		alliance,
		members,
		events: Array.isArray(raw.events) ? raw.events.filter(isEvent) : [],
		rallies: Array.isArray(raw.rallies) ? raw.rallies.filter(isRally) : [],
		tech: Array.isArray(raw.tech) && raw.tech.filter(isTech).length ? raw.tech.filter(isTech) : base.tech,
		forts: Array.isArray(raw.forts) && raw.forts.filter(isFort).length ? raw.forts.filter(isFort) : base.forts,
		duties: Array.isArray(raw.duties) && raw.duties.filter(isDuty).length ? raw.duties.filter(isDuty) : base.duties
	};
}
function clamp(n, min, max) {
	return Math.min(max, Math.max(min, Math.round(n)));
}
function isMember(v) {
	if (!isRecord(v) || typeof v.id !== "string" || typeof v.name !== "string") return false;
	return [
		"R1",
		"R2",
		"R3",
		"R4",
		"R5"
	].includes(v.rank) && [
		"member",
		"captain",
		"builder",
		"farm"
	].includes(v.role) && [
		"active",
		"away",
		"inactive"
	].includes(v.presence) && typeof v.power === "number" && typeof v.furnace === "number";
}
function isEvent(v) {
	if (!isRecord(v) || typeof v.id !== "string" || typeof v.title !== "string") return false;
	return typeof v.startsAt === "number" && typeof v.kind === "string" && isRecord(v.rsvp);
}
function isRally(v) {
	if (!isRecord(v) || typeof v.id !== "string" || typeof v.target !== "string") return false;
	return typeof v.captainId === "string" && typeof v.startsAt === "number";
}
function isTech(v) {
	if (!isRecord(v) || typeof v.id !== "string" || typeof v.name !== "string") return false;
	return typeof v.level === "number" && typeof v.max === "number" && typeof v.tree === "string";
}
function isFort(v) {
	return isRecord(v) && typeof v.id === "string" && typeof v.name === "string" && typeof v.status === "string";
}
function isDuty(v) {
	return isRecord(v) && typeof v.id === "string" && typeof v.label === "string" && typeof v.done === "boolean";
}
var FORT_ORDER = [
	"open",
	"target",
	"held",
	"enemy"
];
var memory = {
	getItem: () => null,
	setItem: () => {},
	removeItem: () => {}
};
var useDesk = create()(persist((set) => ({
	...initial(),
	updateAlliance: (patch) => set((s) => ({ alliance: {
		...s.alliance,
		...patch
	} })),
	addMember: (member) => set((s) => ({ members: [...s.members, member] })),
	updateMember: (id, patch) => set((s) => ({ members: s.members.map((m) => m.id === id ? {
		...m,
		...patch
	} : m) })),
	removeMember: (id) => set((s) => ({
		members: s.members.filter((m) => m.id !== id),
		events: s.events.map((e) => {
			const rsvp = { ...e.rsvp };
			delete rsvp[id];
			const lanes = e.lanes ? {
				left: e.lanes.left.filter((x) => x !== id),
				mid: e.lanes.mid.filter((x) => x !== id),
				right: e.lanes.right.filter((x) => x !== id)
			} : e.lanes;
			return {
				...e,
				rsvp,
				lanes
			};
		}),
		rallies: s.rallies.map((r) => r.captainId === id ? {
			...r,
			captainId: s.members.find((m) => m.id !== id)?.id ?? ""
		} : r)
	})),
	addEvent: (event) => set((s) => ({ events: [...s.events, event] })),
	updateEvent: (id, patch) => set((s) => ({ events: s.events.map((e) => e.id === id ? {
		...e,
		...patch
	} : e) })),
	removeEvent: (id) => set((s) => ({ events: s.events.filter((e) => e.id !== id) })),
	setRsvp: (eventId, memberId, value) => set((s) => ({ events: s.events.map((e) => {
		if (e.id !== eventId) return e;
		const rsvp = { ...e.rsvp };
		if (rsvp[memberId] === value) delete rsvp[memberId];
		else rsvp[memberId] = value;
		return {
			...e,
			rsvp
		};
	}) })),
	cycleMemberLane: (eventId, memberId) => set((s) => ({ events: s.events.map((e) => e.id === eventId ? {
		...e,
		lanes: cycleLane(e.lanes ?? emptyLanes(), memberId)
	} : e) })),
	autoLanes: (eventId) => set((s) => ({ events: s.events.map((e) => e.id === eventId ? {
		...e,
		lanes: balanceLanes(e, s.members)
	} : e) })),
	addRally: (rally) => set((s) => ({ rallies: [...s.rallies, rally] })),
	updateRally: (id, patch) => set((s) => ({ rallies: s.rallies.map((r) => r.id === id ? {
		...r,
		...patch
	} : r) })),
	removeRally: (id) => set((s) => ({ rallies: s.rallies.filter((r) => r.id !== id) })),
	setTechLevel: (id, level) => set((s) => ({ tech: s.tech.map((t) => t.id === id ? {
		...t,
		level: Math.max(0, Math.min(t.max, Math.round(level)))
	} : t) })),
	cycleFort: (id) => set((s) => ({ forts: s.forts.map((f) => {
		if (f.id !== id) return f;
		const status = FORT_ORDER[(FORT_ORDER.indexOf(f.status) + 1) % FORT_ORDER.length] ?? "open";
		return {
			...f,
			status
		};
	}) })),
	toggleDuty: (id) => set((s) => ({ duties: s.duties.map((d) => d.id === id ? {
		...d,
		done: !d.done
	} : d) })),
	replaceAll: (data) => set(() => data),
	resetDemo: () => set(() => initial())
}), {
	name: "frostline-desk-v1",
	skipHydration: true,
	storage: createJSONStorage(() => typeof window === "undefined" ? memory : localStorage),
	merge: (persisted, current) => {
		const data = normalizeDesk(persisted);
		if (!data) return current;
		return {
			...current,
			...data
		};
	}
}));
function newId() {
	return crypto.randomUUID();
}
function AllianceSheet({ open, onClose }) {
	const alliance = useDesk((s) => s.alliance);
	const updateAlliance = useDesk((s) => s.updateAlliance);
	const replaceAll = useDesk((s) => s.replaceAll);
	const resetDemo = useDesk((s) => s.resetDemo);
	const fileRef = (0, import_react.useRef)(null);
	const [error, setError] = (0, import_react.useState)("");
	const [confirmReset, setConfirmReset] = (0, import_react.useState)(false);
	function exportDesk() {
		const { alliance: a, members, events, rallies, tech, forts, duties } = useDesk.getState();
		const blob = new Blob([JSON.stringify({
			alliance: a,
			members,
			events,
			rallies,
			tech,
			forts,
			duties
		}, null, 2)], { type: "application/json" });
		const url = URL.createObjectURL(blob);
		const link = document.createElement("a");
		link.href = url;
		link.download = `${a.tag || "alliance"}-frostline.json`;
		link.click();
		URL.revokeObjectURL(url);
	}
	async function onFile(file) {
		if (!file) return;
		setError("");
		try {
			const data = normalizeDesk(JSON.parse(await file.text()));
			if (!data) {
				setError("That file is not a Frostline desk.");
				return;
			}
			replaceAll(data);
			onClose();
		} catch {
			setError("Could not read that file.");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Sheet, {
		open,
		title: "Alliance",
		onClose,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Name",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: controlClass,
					value: alliance.name,
					maxLength: 40,
					onChange: (e) => updateAlliance({ name: e.target.value })
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Tag",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: controlClass,
						value: alliance.tag,
						maxLength: 6,
						onChange: (e) => updateAlliance({ tag: e.target.value.toUpperCase() })
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "State",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: controlClass,
						value: alliance.server,
						maxLength: 12,
						onChange: (e) => updateAlliance({ server: e.target.value })
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Level",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: controlClass,
						inputMode: "numeric",
						value: alliance.level,
						onChange: (e) => updateAlliance({ level: clampNum(e.target.value, 1, 11, alliance.level) })
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Roster cap",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: controlClass,
						inputMode: "numeric",
						value: alliance.cap,
						onChange: (e) => updateAlliance({ cap: clampNum(e.target.value, 10, 120, alliance.cap) })
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Phase",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
					className: controlClass,
					value: alliance.phase,
					onChange: (e) => updateAlliance({ phase: e.target.value }),
					children: PHASES.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: p.id,
						children: p.label
					}, p.id))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-3 text-xs text-muted",
				children: PHASES.find((p) => p.id === alliance.phase)?.hint
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Bear trap level",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: controlClass,
						inputMode: "numeric",
						value: alliance.bearLevel,
						onChange: (e) => updateAlliance({ bearLevel: clampNum(e.target.value, 1, 20, alliance.bearLevel) })
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Donation goal",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: controlClass,
						inputMode: "numeric",
						value: alliance.donationGoal,
						onChange: (e) => updateAlliance({ donationGoal: clampNum(e.target.value, 0, 9999999, alliance.donationGoal) })
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-2 grid grid-cols-2 gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: exportDesk,
					children: "Export"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: () => fileRef.current?.click(),
					children: "Import"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				ref: fileRef,
				type: "file",
				accept: "application/json",
				className: "sr-only",
				onChange: (e) => {
					onFile(e.target.files?.[0]);
					e.target.value = "";
				}
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-danger",
				children: error
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 border-t border-line pt-4",
				children: confirmReset ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "danger",
						className: "flex-1",
						onClick: () => {
							resetDemo();
							setConfirmReset(false);
							onClose();
						},
						children: "Replace with sample"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "flex-1",
						onClick: () => setConfirmReset(false),
						children: "Cancel"
					})]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "quiet",
					onClick: () => setConfirmReset(true),
					children: "Reset to Northwatch sample"
				})
			})
		]
	});
}
function clampNum(raw, min, max, prev) {
	if (raw.trim() === "") return min;
	const n = Number(raw);
	if (!Number.isFinite(n)) return prev;
	return Math.min(max, Math.max(min, Math.round(n)));
}
function Brief({ now, onOpenOps, onTab }) {
	const alliance = useDesk((s) => s.alliance);
	const members = useDesk((s) => s.members);
	const events = useDesk((s) => s.events);
	const rallies = useDesk((s) => s.rallies);
	const tech = useDesk((s) => s.tech);
	const duties = useDesk((s) => s.duties);
	const toggleDuty = useDesk((s) => s.toggleDuty);
	const [settings, setSettings] = (0, import_react.useState)(false);
	const event = nextEvent(events, now);
	const counts = event ? rsvpCounts(event, members) : null;
	const rec = recommendation(tech, alliance.phase);
	const review = members.filter((m) => m.presence === "inactive");
	const openRallies = rallies.filter((r) => r.status !== "done");
	const donatePct = alliance.donationGoal ? Math.min(100, Math.round(alliance.donations / alliance.donationGoal * 100)) : 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "mb-5 flex items-start justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium text-faint",
						children: "Frostline"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "truncate text-xl font-semibold tracking-tight",
						children: alliance.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted",
						children: [
							alliance.tag,
							" · State ",
							alliance.server,
							" · Level ",
							alliance.level,
							" · ",
							members.length,
							"/",
							alliance.cap
						]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				className: "w-11 shrink-0 px-0",
				"aria-label": "Alliance settings",
				onClick: () => setSettings(true),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings, {
					size: 18,
					strokeWidth: 1.75
				})
			})]
		}),
		event && counts ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			className: "mb-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium text-faint",
					children: "Next operation"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-1 flex items-end justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-lg font-semibold tracking-tight",
						children: event.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "nums text-sm text-muted",
						children: formatWhen(event.startsAt, now)
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "nums mt-1 text-3xl font-medium tracking-tight",
					children: formatCountdown(event.startsAt, now)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 grid grid-cols-4 gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Count, {
							label: "In",
							value: counts.inn
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Count, {
							label: "Out",
							value: counts.out
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Count, {
							label: "Maybe",
							value: counts.maybe
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Count, {
							label: "Silent",
							value: counts.silent
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-muted",
					children: KIND_INFO[event.kind].rule || event.note
				}),
				counts.silent > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 text-sm text-fg",
					children: ["No reply: ", namesFor(event, members, "silent").join(", ")]
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 flex flex-wrap gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "primary",
						onClick: () => onOpenOps("events", event.id),
						children: "Take attendance"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: () => onTab("orders"),
						children: "Draft orders"
					})]
				})
			]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			className: "mb-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-lg font-semibold",
					children: "No operations scheduled"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: "Add a bear, fortress, or mobilization from Ops."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					className: "mt-4",
					variant: "primary",
					onClick: () => onOpenOps("events"),
					children: "Open ops"
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-3 md:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-sm font-semibold",
				children: "Officer loop"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-2",
				children: duties.map((duty) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "border-b border-line last:border-b-0",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => toggleDuty(duty.id),
						className: "flex min-h-11 w-full items-center gap-3 py-2 text-left",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: duty.done ? "grid h-5 w-5 shrink-0 place-items-center rounded-sm bg-accent text-accent-fg" : "h-5 w-5 shrink-0 rounded-sm border border-line",
							"aria-hidden": "true",
							children: duty.done ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
								viewBox: "0 0 16 16",
								className: "h-3 w-3",
								fill: "none",
								stroke: "currentColor",
								strokeWidth: "2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M3 8.5 6.2 12 13 4" })
							}) : null
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: duty.done ? "text-sm text-muted line-through" : "text-sm text-fg",
							children: duty.label
						})]
					})
				}, duty.id))
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-sm font-semibold",
							children: "Research next"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-fg",
							children: rec.node ? `${rec.node.name} ${rec.node.level}/${rec.node.max}` : "Tree complete"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-xs text-muted",
							children: rec.why
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: () => onTab("tech"),
						children: "Tech"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-1 flex justify-between text-xs text-muted",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Donations today" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "nums",
							children: [
								alliance.donations.toLocaleString(),
								" / ",
								alliance.donationGoal.toLocaleString()
							]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-1.5 overflow-hidden rounded-sm bg-bg",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-full bg-accent",
							style: { width: `${donatePct}%` }
						})
					})]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-2 flex items-center justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-semibold",
						children: "Rallies"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "quiet",
						onClick: () => onOpenOps("rallies"),
						children: "Board"
					})]
				}), openRallies.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "No open rallies."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "space-y-3",
					children: openRallies.map((rally) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-baseline justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "truncate text-sm font-medium",
								children: rally.target
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "truncate text-xs text-muted",
								children: [
									memberName(members, rally.captainId),
									" · ",
									rally.hero || "No hero set"
								]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "nums shrink-0 text-xs text-muted",
							children: [
								rally.filled,
								"/",
								rally.slots,
								" · ",
								formatCountdown(rally.startsAt, now)
							]
						})]
					}, rally.id))
				})] })]
			})]
		}),
		review.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			className: "mt-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-sm font-semibold",
				children: "Roster review"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-2 space-y-2",
				children: review.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-baseline justify-between gap-3 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "min-w-0 truncate",
						children: [m.name, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-muted",
							children: [
								" · ",
								m.rank,
								" · ",
								formatPower(m.power)
							]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "shrink-0 text-xs text-faint",
						children: m.note || "No note"
					})]
				}, m.id))
			})]
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-4 text-xs text-faint",
			children: "Saved on this device. Export a copy from alliance settings if you switch phones. Sample data is Northwatch — replace it with yours."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AllianceSheet, {
			open: settings,
			onClose: () => setSettings(false)
		})
	] });
}
function Count({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-sm bg-bg px-2 py-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "nums text-lg font-medium",
			children: value
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-xs text-muted",
			children: label
		})]
	});
}
var SECTIONS = [
	{
		id: "events",
		label: "Events"
	},
	{
		id: "rallies",
		label: "Rallies"
	},
	{
		id: "forts",
		label: "Forts"
	}
];
var KINDS = Object.keys(KIND_INFO).filter((k) => k !== "custom");
function Ops({ now, section, onSection, focusId }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ViewHeader, {
			kicker: "Operations",
			title: "War board"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Segment, {
			label: "Operations",
			value: section,
			options: SECTIONS,
			onChange: onSection
		}),
		section === "events" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Events, {
			now,
			focusId
		}) : null,
		section === "rallies" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Rallies, { now }) : null,
		section === "forts" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Forts, {}) : null
	] });
}
function Events({ now, focusId }) {
	const events = useDesk((s) => s.events);
	const members = useDesk((s) => s.members);
	const addEvent = useDesk((s) => s.addEvent);
	const updateEvent = useDesk((s) => s.updateEvent);
	const removeEvent = useDesk((s) => s.removeEvent);
	const setRsvp = useDesk((s) => s.setRsvp);
	const cycleMemberLane = useDesk((s) => s.cycleMemberLane);
	const autoLanes = useDesk((s) => s.autoLanes);
	const sorted = [...events].sort((a, b) => a.startsAt - b.startsAt);
	const [selected, setSelected] = (0, import_react.useState)(focusId ?? nextEvent(events, now)?.id ?? null);
	const [adding, setAdding] = (0, import_react.useState)(false);
	const [armRemove, setArmRemove] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (focusId) setSelected(focusId);
	}, [focusId]);
	(0, import_react.useEffect)(() => {
		setArmRemove(false);
	}, [selected]);
	const event = sorted.find((e) => e.id === selected) ?? sorted[0] ?? null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-3 flex items-center justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Mark who is in. Tap again to clear."
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				variant: "primary",
				onClick: () => setAdding(true),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 16 }), "Event"]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex gap-2 overflow-x-auto pb-1",
			children: sorted.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setSelected(item.id),
				className: clsx("press h-11 shrink-0 rounded-sm px-3 text-sm font-medium", event?.id === item.id ? "bg-accent text-accent-fg" : "border border-line bg-surface text-muted"),
				children: item.title
			}, item.id))
		}),
		event ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
			className: "mt-3 rounded-xl border border-line bg-surface p-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-lg font-semibold tracking-tight",
						children: event.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted",
						children: [
							formatWhen(event.startsAt, now),
							" · ",
							formatCountdown(event.startsAt, now)
						]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "quiet",
						onClick: () => {
							if (!armRemove) {
								setArmRemove(true);
								return;
							}
							removeEvent(event.id);
							setSelected(null);
							setArmRemove(false);
						},
						children: armRemove ? "Confirm remove" : "Remove"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-xs text-faint",
					children: (KIND_INFO[event.kind] ?? KIND_INFO.custom).cadence
				}),
				(KIND_INFO[event.kind] ?? KIND_INFO.custom).rule ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted",
					children: (KIND_INFO[event.kind] ?? KIND_INFO.custom).rule
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Call note",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						className: areaClass,
						value: event.note,
						maxLength: 240,
						onChange: (e) => updateEvent(event.id, { note: e.target.value })
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Starts",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "datetime-local",
						className: controlClass,
						value: toLocalInput(event.startsAt),
						onChange: (e) => updateEvent(event.id, { startsAt: fromLocalInput(e.target.value) })
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "mb-1 text-sm font-semibold",
					children: "Attendance"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "divide-y divide-line",
					children: sortedMembers(members).map((m) => {
						const value = event.rsvp[m.id];
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "py-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mb-2 flex items-baseline justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "truncate text-sm font-medium",
									children: m.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "nums shrink-0 text-xs text-faint",
									children: m.rank
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid grid-cols-3 gap-2",
								children: [
									"in",
									"out",
									"maybe"
								].map((option) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									"aria-pressed": value === option,
									onClick: () => setRsvp(event.id, m.id, option),
									className: clsx("press h-11 rounded-sm text-sm font-medium", value === option ? "bg-accent text-accent-fg" : "bg-bg text-muted"),
									children: option === "in" ? "In" : option === "out" ? "Out" : "Maybe"
								}, option))
							})]
						}, m.id);
					})
				}),
				event.kind === "championship" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lanes, {
					event,
					onCycle: (id) => cycleMemberLane(event.id, id),
					onBalance: () => autoLanes(event.id)
				}) : null
			]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-4 text-sm text-muted",
			children: "No events yet."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
			open: adding,
			title: "Add event",
			onClose: () => setAdding(false),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-2",
				children: KINDS.map((kind) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "press rounded-lg border border-line bg-bg px-3 py-3 text-left",
					onClick: () => {
						const created = {
							id: newId(),
							kind,
							title: KIND_INFO[kind].label,
							startsAt: defaultStart(kind, now),
							note: "",
							rsvp: {},
							lanes: kind === "championship" ? {
								left: [],
								mid: [],
								right: []
							} : void 0
						};
						addEvent(created);
						setSelected(created.id);
						setAdding(false);
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-sm font-medium",
						children: KIND_INFO[kind].label
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-xs text-muted",
						children: KIND_INFO[kind].cadence
					})]
				}, kind))
			})
		})
	] });
}
function Lanes({ event, onCycle, onBalance }) {
	const members = useDesk((s) => s.members);
	const lanes = event.lanes ?? {
		left: [],
		mid: [],
		right: []
	};
	const assigned = /* @__PURE__ */ new Set([
		...lanes.left,
		...lanes.mid,
		...lanes.right
	]);
	const pool = sortedMembers(members).filter((m) => event.rsvp[m.id] === "in");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-4 border-t border-line pt-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3 flex items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "text-sm font-semibold",
					children: "Lanes"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: onBalance,
					children: "Balance by power"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-3 text-xs text-muted",
				children: "Tap a name to move it: mid, left, right, then off the card."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-2 sm:grid-cols-3",
				children: [
					"mid",
					"left",
					"right"
				].map((key) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-md bg-bg p-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium capitalize text-muted",
						children: key
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "mt-2 space-y-1",
						children: [lanes[key].length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "text-sm text-faint",
							children: "Empty"
						}) : null, lanes[key].map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "h-11 w-full text-left text-sm font-medium",
							onClick: () => onCycle(id),
							children: memberName(members, id)
						}) }, id))]
					})]
				}, key))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 flex flex-wrap gap-2",
				children: pool.filter((m) => !assigned.has(m.id)).map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => onCycle(m.id),
					className: "press h-11 rounded-sm border border-line px-3 text-sm",
					children: m.name
				}, m.id))
			})
		]
	});
}
function Rallies({ now }) {
	const rallies = useDesk((s) => s.rallies);
	const members = useDesk((s) => s.members);
	const addRally = useDesk((s) => s.addRally);
	const updateRally = useDesk((s) => s.updateRally);
	const removeRally = useDesk((s) => s.removeRally);
	const [editing, setEditing] = (0, import_react.useState)(null);
	const [isNew, setIsNew] = (0, import_react.useState)(false);
	const sorted = [...rallies].sort((a, b) => a.startsAt - b.startsAt);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mb-3 flex justify-end",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				variant: "primary",
				onClick: () => {
					setIsNew(true);
					setEditing({
						id: newId(),
						target: "Polar Terror 6",
						captainId: members.find((m) => m.role === "captain")?.id ?? members[0]?.id ?? "",
						startsAt: now + 36e5,
						slots: 8,
						filled: 1,
						hero: "",
						status: "forming"
					});
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 16 }), "Rally"]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
			className: "space-y-2",
			children: [sorted.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
				className: "text-sm text-muted",
				children: "No rallies on the board."
			}) : null, sorted.map((rally) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => {
					setIsNew(false);
					setEditing(rally);
				},
				className: "w-full rounded-xl border border-line bg-surface p-4 text-left",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-baseline justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-base font-semibold",
							children: rally.target
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "nums text-xs text-muted",
							children: [
								rally.filled,
								"/",
								rally.slots
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-sm text-muted",
						children: [
							memberName(members, rally.captainId),
							" · ",
							rally.status,
							" · ",
							formatWhen(rally.startsAt, now)
						]
					}),
					rally.hero ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-xs text-faint",
						children: ["First slot: ", rally.hero]
					}) : null,
					/bear/i.test(rally.target) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-xs text-muted",
						children: KIND_INFO.bear.rule
					}) : null
				]
			}) }, rally.id))]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RallySheet, {
			rally: editing,
			isNew,
			onClose: () => setEditing(null),
			onSave: (rally) => {
				if (isNew) addRally(rally);
				else updateRally(rally.id, rally);
				setEditing(null);
			},
			onRemove: (id) => {
				removeRally(id);
				setEditing(null);
			}
		})
	] });
}
function RallySheet({ rally, isNew, onClose, onSave, onRemove }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
		open: !!rally,
		title: isNew ? "New rally" : "Rally",
		onClose,
		children: rally ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RallyForm, {
			rally,
			isNew,
			onSave,
			onRemove
		}, rally.id) : null
	});
}
function RallyForm({ rally, isNew, onSave, onRemove }) {
	const members = useDesk((s) => s.members);
	const [draft, setDraft] = (0, import_react.useState)(rally);
	const [confirm, setConfirm] = (0, import_react.useState)(false);
	const patch = (p) => setDraft((d) => ({
		...d,
		...p
	}));
	const captains = sortedMembers(members);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, {
			label: "Target",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				className: controlClass,
				list: "rally-targets",
				value: draft.target,
				maxLength: 40,
				onChange: (e) => patch({ target: e.target.value })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("datalist", {
				id: "rally-targets",
				children: [
					"Bear",
					"Polar Terror 5",
					"Polar Terror 6",
					"Polar Terror 7",
					"Polar Terror 8",
					"Cryptid",
					"City"
				].map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { value: t }, t))
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
			label: "Captain",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
				className: controlClass,
				value: draft.captainId,
				onChange: (e) => patch({ captainId: e.target.value }),
				children: captains.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
					value: m.id,
					children: [
						m.name,
						" · ",
						m.rank
					]
				}, m.id))
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
			label: "Starts",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				type: "datetime-local",
				className: controlClass,
				value: toLocalInput(draft.startsAt),
				onChange: (e) => patch({ startsAt: fromLocalInput(e.target.value) })
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-2 gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Filled",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: controlClass,
					inputMode: "numeric",
					value: draft.filled,
					onChange: (e) => {
						const n = Number(e.target.value);
						if (Number.isFinite(n)) patch({ filled: Math.max(0, Math.min(draft.slots, Math.round(n))) });
					}
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Slots",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: controlClass,
					inputMode: "numeric",
					value: draft.slots,
					onChange: (e) => {
						const n = Number(e.target.value);
						if (Number.isFinite(n)) {
							const slots = Math.max(1, Math.min(20, Math.round(n)));
							patch({
								slots,
								filled: Math.min(draft.filled, slots)
							});
						}
					}
				})
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
			label: "First-slot hero",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				className: controlClass,
				value: draft.hero,
				maxLength: 48,
				placeholder: "Jessie",
				onChange: (e) => patch({ hero: e.target.value })
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
			label: "Status",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
				className: controlClass,
				value: draft.status,
				onChange: (e) => patch({ status: e.target.value }),
				children: RALLY_STATUS.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
					value: s,
					children: s
				}, s))
			})
		}),
		/bear/i.test(draft.target) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mb-3 text-xs text-muted",
			children: KIND_INFO.bear.rule
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			variant: "primary",
			className: "w-full",
			disabled: !draft.target.trim() || !draft.captainId,
			onClick: () => onSave({
				...draft,
				target: draft.target.trim()
			}),
			children: "Save rally"
		}),
		!isNew ? confirm ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-2 grid grid-cols-2 gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "danger",
				onClick: () => onRemove(draft.id),
				children: "Confirm remove"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: () => setConfirm(false),
				children: "Cancel"
			})]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			variant: "quiet",
			className: "mt-2 w-full",
			onClick: () => setConfirm(true),
			children: "Remove rally"
		}) : null
	] });
}
function Forts() {
	const forts = useDesk((s) => s.forts);
	const cycleFort = useDesk((s) => s.cycleFort);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "mb-3 text-sm text-muted",
		children: "Tap a structure to cycle Open, Target, Held, Enemy. Hold a target for 30 minutes on Friday."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "grid gap-2 sm:grid-cols-2",
		children: forts.map((fort) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			onClick: () => cycleFort(fort.id),
			className: "press flex min-h-16 w-full items-center justify-between gap-3 rounded-xl border border-line bg-surface px-3 py-3 text-left",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "min-w-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block truncate text-sm font-medium",
					children: fort.name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block truncate text-xs text-muted",
					children: fort.buff
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusPill, { status: fort.status })]
		}) }, fort.id))
	})] });
}
function StatusPill({ status }) {
	const label = FORT_STATUS.find((s) => s.id === status)?.label ?? status;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: clsx("shrink-0 text-xs font-medium", status === "held" ? "text-ok" : status === "target" ? "text-fg" : status === "enemy" ? "text-danger" : "text-faint"),
		children: label
	});
}
var PINGS = [
	{
		id: "full",
		label: "Full orders"
	},
	{
		id: "bear",
		label: "Bear"
	},
	{
		id: "silent",
		label: "Silent"
	},
	{
		id: "donate",
		label: "Donate"
	},
	{
		id: "forts",
		label: "Forts"
	},
	{
		id: "lanes",
		label: "Lanes"
	}
];
function Orders({ now }) {
	const data = useDesk();
	const updateAlliance = useDesk((s) => s.updateAlliance);
	const [kind, setKind] = (0, import_react.useState)("full");
	const [copied, setCopied] = (0, import_react.useState)(false);
	const ping = (0, import_react.useMemo)(() => buildPing(kind, data, now), [
		kind,
		data,
		now
	]);
	async function copy() {
		const text = ping.body;
		try {
			await navigator.clipboard.writeText(text);
		} catch {
			const area = document.createElement("textarea");
			area.value = text;
			document.body.appendChild(area);
			area.select();
			document.execCommand("copy");
			area.remove();
		}
		setCopied(true);
		window.setTimeout(() => setCopied(false), 1600);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ViewHeader, {
			kicker: "Chat copy",
			title: "Orders",
			action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				variant: "primary",
				onClick: () => void copy(),
				children: [copied ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { size: 16 }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { size: 16 }), copied ? "Copied" : "Copy"]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mb-3 text-sm text-muted",
			children: "Paste into alliance chat or Discord. The text follows the roster, attendance, and targets on this desk."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mb-3 flex gap-2 overflow-x-auto pb-1",
			children: PINGS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => {
					setKind(item.id);
					setCopied(false);
				},
				className: clsx("press h-11 shrink-0 rounded-sm px-3 text-sm font-medium", kind === item.id ? "bg-accent text-accent-fg" : "border border-line bg-surface text-muted"),
				children: item.label
			}, item.id))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
			className: "nums overflow-x-auto rounded-xl border border-line bg-surface p-4 text-xs leading-relaxed whitespace-pre-wrap text-fg",
			children: ping.body
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
			label: "Standing note, included in full orders",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
				className: areaClass,
				maxLength: 400,
				value: data.alliance.ordersNote,
				onChange: (e) => updateAlliance({ ordersNote: e.target.value })
			})
		})
	] });
}
var FILTERS = [
	{
		id: "all",
		label: "All"
	},
	{
		id: "officers",
		label: "R4+"
	},
	{
		id: "captains",
		label: "Captains"
	},
	{
		id: "review",
		label: "Review"
	}
];
var blank = () => ({
	id: newId(),
	name: "",
	rank: "R1",
	power: 2e7,
	furnace: 20,
	role: "member",
	presence: "active",
	note: ""
});
function Roster() {
	const members = useDesk((s) => s.members);
	const addMember = useDesk((s) => s.addMember);
	const updateMember = useDesk((s) => s.updateMember);
	const removeMember = useDesk((s) => s.removeMember);
	const [filter, setFilter] = (0, import_react.useState)("all");
	const [query, setQuery] = (0, import_react.useState)("");
	const [editing, setEditing] = (0, import_react.useState)(null);
	const [isNew, setIsNew] = (0, import_react.useState)(false);
	const list = (0, import_react.useMemo)(() => {
		const q = query.trim().toLowerCase();
		return sortedMembers(members).filter((m) => {
			if (q && !m.name.toLowerCase().includes(q)) return false;
			if (filter === "officers") return m.rank === "R4" || m.rank === "R5";
			if (filter === "captains") return m.role === "captain";
			if (filter === "review") return m.presence !== "active";
			return true;
		});
	}, [
		members,
		filter,
		query
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ViewHeader, {
			kicker: "Alliance",
			title: "Roster",
			action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				variant: "primary",
				onClick: () => {
					setIsNew(true);
					setEditing(blank());
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 16 }), "Add"]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mb-3 text-sm text-muted",
			children: [members.length, " on the list. Ranks, power, and who is drifting."]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			className: controlClass,
			placeholder: "Search names",
			value: query,
			onChange: (e) => setQuery(e.target.value),
			"aria-label": "Search roster"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-3 flex gap-2 overflow-x-auto pb-1",
			children: FILTERS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setFilter(item.id),
				className: clsx("press h-11 shrink-0 rounded-sm px-3 text-sm font-medium", filter === item.id ? "bg-accent text-accent-fg" : "border border-line bg-surface text-muted"),
				children: item.label
			}, item.id))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-3 divide-y divide-line rounded-xl border border-line bg-surface",
			children: list.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
				className: "p-4 text-sm text-muted",
				children: "No one matches."
			}) : list.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => {
					setIsNew(false);
					setEditing(m);
				},
				className: "flex min-h-14 w-full items-center gap-3 px-3 py-2 text-left",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "nums w-8 shrink-0 text-xs text-faint",
						children: m.rank
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block truncate text-sm font-medium",
							children: m.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "block truncate text-xs text-muted",
							children: [roleLabel(m.role), m.note ? ` · ${m.note}` : ""]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "shrink-0 text-right",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "nums block text-sm",
							children: formatPower(m.power)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "block text-xs text-faint",
							children: [
								"FC ",
								m.furnace,
								m.presence !== "active" ? ` · ${presenceLabel(m.presence)}` : ""
							]
						})]
					})
				]
			}) }, m.id))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MemberSheet, {
			member: editing,
			isNew,
			onClose: () => setEditing(null),
			onSave: (member) => {
				if (!member.name.trim()) return;
				if (isNew) addMember({
					...member,
					name: member.name.trim()
				});
				else updateMember(member.id, {
					...member,
					name: member.name.trim()
				});
				setEditing(null);
			},
			onRemove: (id) => {
				removeMember(id);
				setEditing(null);
			}
		})
	] });
}
function MemberSheet({ member, isNew, onClose, onSave, onRemove }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
		open: !!member,
		title: isNew ? "Add member" : "Member",
		onClose,
		children: member ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MemberForm, {
			member,
			isNew,
			onSave,
			onRemove
		}, member.id) : null
	});
}
function MemberForm({ member, isNew, onSave, onRemove }) {
	const [draft, setDraft] = (0, import_react.useState)(member);
	const [confirm, setConfirm] = (0, import_react.useState)(false);
	const [powerText, setPowerText] = (0, import_react.useState)(() => member.power ? String(Math.round(member.power / 1e6 * 10) / 10) : "");
	const patch = (p) => setDraft((d) => ({
		...d,
		...p
	}));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
			label: "Name",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				className: controlClass,
				value: draft.name,
				maxLength: 24,
				onChange: (e) => patch({ name: e.target.value })
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-2 gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Rank",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
					className: controlClass,
					value: draft.rank,
					onChange: (e) => patch({ rank: e.target.value }),
					children: RANKS.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: r }, r))
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Role",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
					className: controlClass,
					value: draft.role,
					onChange: (e) => patch({ role: e.target.value }),
					children: ROLES.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: r.id,
						children: r.label
					}, r.id))
				})
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-2 gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Power (millions)",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: controlClass,
					inputMode: "decimal",
					value: powerText,
					onChange: (e) => {
						const raw = e.target.value;
						if (raw !== "" && !/^\d*\.?\d{0,1}$/.test(raw)) return;
						setPowerText(raw);
						const n = Number(raw);
						if (raw === "" || raw === ".") patch({ power: 0 });
						else if (Number.isFinite(n) && n >= 0) patch({ power: Math.round(n * 1e6) });
					}
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Furnace",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: controlClass,
					inputMode: "numeric",
					value: draft.furnace,
					onChange: (e) => {
						const n = Number(e.target.value);
						if (Number.isFinite(n)) patch({ furnace: Math.min(30, Math.max(1, Math.round(n))) });
					}
				})
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
			label: "Status",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
				className: controlClass,
				value: draft.presence,
				onChange: (e) => patch({ presence: e.target.value }),
				children: PRESENCE.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
					value: p.id,
					children: p.label
				}, p.id))
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
			label: "Note",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
				className: areaClass,
				maxLength: 160,
				value: draft.note,
				onChange: (e) => patch({ note: e.target.value })
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			variant: "primary",
			className: "w-full",
			disabled: !draft.name.trim(),
			onClick: () => onSave(draft),
			children: "Save"
		}),
		!isNew ? confirm ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-2 grid grid-cols-2 gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "danger",
				onClick: () => onRemove(draft.id),
				children: "Confirm remove"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: () => setConfirm(false),
				children: "Cancel"
			})]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			variant: "quiet",
			className: "mt-2 w-full",
			onClick: () => setConfirm(true),
			children: "Remove from roster"
		}) : null
	] });
}
function roleLabel(role) {
	return ROLES.find((r) => r.id === role)?.label ?? role;
}
function presenceLabel(presence) {
	return PRESENCE.find((p) => p.id === presence)?.label ?? presence;
}
var TREES = [
	"growth",
	"territory",
	"battle"
];
function TechView() {
	const alliance = useDesk((s) => s.alliance);
	const tech = useDesk((s) => s.tech);
	const updateAlliance = useDesk((s) => s.updateAlliance);
	const setTechLevel = useDesk((s) => s.setTechLevel);
	const rec = recommendation(tech, alliance.phase);
	const donatePct = alliance.donationGoal ? Math.min(100, Math.round(alliance.donations / alliance.donationGoal * 100)) : 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ViewHeader, {
			kicker: "Alliance tech",
			title: "Research"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			className: "mb-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium text-faint",
					children: "Next for this phase"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-1 text-lg font-semibold tracking-tight",
					children: rec.node ? rec.node.name : "Nothing open"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: rec.why
				}),
				rec.node ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "nums mt-2 text-sm text-fg",
					children: [
						rec.node.level,
						"/",
						rec.node.max,
						" · ",
						rec.node.effect
					]
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-1 flex justify-between text-xs text-muted",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Donated today" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "nums",
								children: [
									alliance.donations.toLocaleString(),
									" / ",
									alliance.donationGoal.toLocaleString()
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-1.5 overflow-hidden rounded-sm bg-bg",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "h-full bg-accent",
								style: { width: `${donatePct}%` }
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "mt-3 block",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mb-1 block text-xs font-medium text-muted",
								children: "Update today's donations"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: controlClass,
								inputMode: "numeric",
								value: alliance.donations,
								onChange: (e) => {
									const n = Number(e.target.value);
									if (e.target.value === "") updateAlliance({ donations: 0 });
									else if (Number.isFinite(n) && n >= 0) updateAlliance({ donations: Math.round(n) });
								}
							})]
						})
					]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mb-4 grid grid-cols-3 gap-2",
			children: PHASES.map((phase) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => updateAlliance({ phase: phase.id }),
				className: clsx("press h-11 rounded-sm text-sm font-medium", alliance.phase === phase.id ? "bg-accent text-accent-fg" : "border border-line bg-surface text-muted"),
				children: phase.label
			}, phase.id))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mb-4 text-sm text-muted",
			children: PHASES.find((p) => p.id === alliance.phase)?.hint
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "space-y-5",
			children: TREES.map((tree) => {
				const progress = treeProgress(tech, tree);
				const nodes = tech.filter((n) => n.tree === tree);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-2 flex items-baseline justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-sm font-semibold",
							children: TREE_LABEL[tree]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "nums text-xs text-muted",
							children: [
								progress.cur,
								"/",
								progress.max,
								" · ",
								progress.pct,
								"%"
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mb-2 h-1.5 overflow-hidden rounded-sm bg-raised",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-full bg-accent",
							style: { width: `${progress.pct}%` }
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "divide-y divide-line rounded-xl border border-line bg-surface",
						children: nodes.map((node) => {
							const next = rec.node?.id === node.id;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex items-center gap-3 px-3 py-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0 flex-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "truncate text-sm font-medium",
										children: [node.name, next ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "ml-2 text-xs font-medium text-faint",
											children: "Next"
										}) : null]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "truncate text-xs text-muted",
										children: node.effect
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											className: "w-11 px-0",
											"aria-label": `Decrease ${node.name}`,
											disabled: node.level <= 0,
											onClick: () => setTechLevel(node.id, node.level - 1),
											children: "−"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "nums w-10 text-center text-sm",
											children: [
												node.level,
												"/",
												node.max
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											className: "w-11 px-0",
											"aria-label": `Increase ${node.name}`,
											disabled: node.level >= node.max,
											onClick: () => setTechLevel(node.id, node.level + 1),
											children: "+"
										})
									]
								})]
							}, node.id);
						})
					})
				] }, tree);
			})
		})
	] });
}
var TABS = [
	{
		id: "brief",
		label: "Brief",
		icon: Compass
	},
	{
		id: "roster",
		label: "Roster",
		icon: Users
	},
	{
		id: "ops",
		label: "Ops",
		icon: Swords
	},
	{
		id: "tech",
		label: "Tech",
		icon: Layers
	},
	{
		id: "orders",
		label: "Orders",
		icon: ScrollText
	}
];
function useNow(ms = 3e4) {
	const [now, setNow] = (0, import_react.useState)(() => Date.now());
	(0, import_react.useEffect)(() => {
		const id = window.setInterval(() => setNow(Date.now()), ms);
		return () => window.clearInterval(id);
	}, [ms]);
	return now;
}
function Desk() {
	const [tab, setTab] = (0, import_react.useState)("brief");
	const [section, setSection] = (0, import_react.useState)("events");
	const [eventFocus, setEventFocus] = (0, import_react.useState)(null);
	const alliance = useDesk((s) => s.alliance);
	const resetDemo = useDesk((s) => s.resetDemo);
	const now = useNow();
	(0, import_react.useEffect)(() => {
		useDesk.persist.rehydrate();
	}, []);
	function openOps(next, eventId) {
		setSection(next);
		if (eventId) setEventFocus(eventId);
		setTab("ops");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-bg text-fg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex max-w-6xl",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "sticky top-0 hidden h-screen w-56 shrink-0 flex-col border-r border-line md:flex",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "px-4 pt-6 pb-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium text-faint",
						children: "Frostline"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "truncate text-base font-semibold tracking-tight",
						children: alliance?.name ?? "Alliance desk"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "flex flex-col gap-1 px-3",
					"aria-label": "Sections",
					children: TABS.map((item) => {
						const Icon = item.icon;
						const on = tab === item.id;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							"aria-current": on ? "page" : void 0,
							onClick: () => setTab(item.id),
							className: clsx("press flex h-11 items-center gap-3 rounded-md px-3 text-sm font-medium", on ? "bg-raised text-fg" : "text-muted"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
								size: 18,
								strokeWidth: 1.75
							}), item.label]
						}, item.id);
					})
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "pb-nav min-w-0 flex-1 px-4 pt-5 md:px-8 md:pt-8",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "rise w-full max-w-3xl",
					children: !alliance?.name ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl border border-line bg-surface p-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "text-xl font-semibold",
								children: "Desk data is unreadable"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-muted",
								children: "Restore the sample alliance and start again."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "press mt-4 h-11 rounded-sm bg-accent px-3 text-sm font-medium text-accent-fg",
								onClick: resetDemo,
								children: "Restore sample"
							})
						]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						tab === "brief" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Brief, {
							now,
							onOpenOps: openOps,
							onTab: setTab
						}),
						tab === "roster" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Roster, {}),
						tab === "ops" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ops, {
							now,
							section,
							onSection: setSection,
							focusId: eventFocus
						}),
						tab === "tech" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TechView, {}),
						tab === "orders" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Orders, { now })
					] })
				})
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
			className: "nav-safe fixed inset-x-0 bottom-0 z-30 border-t border-line bg-surface md:hidden",
			"aria-label": "Sections",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-5",
				children: TABS.map((item) => {
					const Icon = item.icon;
					const on = tab === item.id;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						"aria-current": on ? "page" : void 0,
						onClick: () => setTab(item.id),
						className: clsx("flex h-16 flex-col items-center justify-center gap-1 text-xs font-medium", on ? "text-fg" : "text-faint"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
							size: 18,
							strokeWidth: 1.75
						}), item.label]
					}, item.id);
				})
			})
		})]
	});
}
function Home() {
	const [ready, setReady] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => setReady(true), []);
	if (!ready) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "min-h-screen bg-bg px-4 pt-6 text-fg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs font-medium text-faint",
			children: "Frostline"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "text-xl font-semibold tracking-tight",
			children: "Alliance desk"
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Desk, {});
}
//#endregion
export { Home as component };
