//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CiNZsIp5.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-TswrDRee.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-TswrDRee.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-D9i9-1Kr.js"]
	}
} });
//#endregion
export { tsrStartManifest };
