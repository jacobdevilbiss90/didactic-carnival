import { useState } from "react";
import { Settings } from "lucide-react";
import { AllianceSheet } from "@/components/alliance-sheet";
import type { OpsSection } from "@/components/ops";
import type { Tab } from "@/components/desk";
import { Button, Card } from "@/components/ui";
import {
  KIND_INFO,
  formatCountdown,
  formatPower,
  formatWhen,
  memberName,
  namesFor,
  nextEvent,
  recommendation,
  rsvpCounts,
} from "@/lib/wos/model";
import { useDesk } from "@/lib/wos/store";

export function Brief({
  now,
  onOpenOps,
  onTab,
}: {
  now: number | null;
  onOpenOps: (section: OpsSection, eventId?: string) => void;
  onTab: (tab: Tab) => void;
}) {
  const alliance = useDesk((s) => s.alliance);
  const members = useDesk((s) => s.members);
  const events = useDesk((s) => s.events);
  const rallies = useDesk((s) => s.rallies);
  const tech = useDesk((s) => s.tech);
  const duties = useDesk((s) => s.duties);
  const toggleDuty = useDesk((s) => s.toggleDuty);
  const [settings, setSettings] = useState(false);

  const event =
    now == null ? (events.find((item) => item.kind === "bear") ?? events[0] ?? null) : nextEvent(events, now);
  const counts = event ? rsvpCounts(event, members) : null;
  const rec = recommendation(tech, alliance.phase);
  const review = members.filter((m) => m.presence === "inactive");
  const openRallies = rallies.filter((r) => r.status !== "done");
  const donatePct = alliance.donationGoal
    ? Math.min(100, Math.round((alliance.donations / alliance.donationGoal) * 100))
    : 0;

  return (
    <div>
      <header className="mb-5 flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="text-xs font-medium text-faint">Frostline</p>
          <h1 className="truncate text-xl font-semibold tracking-tight">{alliance.name}</h1>
          <p className="text-sm text-muted">
            {alliance.tag} · State {alliance.server} · Level {alliance.level} · {members.length}/{alliance.cap}
          </p>
        </div>
        <Button className="w-11 shrink-0 px-0" aria-label="Alliance settings" onClick={() => setSettings(true)}>
          <Settings size={18} strokeWidth={1.75} />
        </Button>
      </header>

      {event && counts ? (
        <Card className="mb-3">
          <p className="text-xs font-medium text-faint">Next operation</p>
          <div className="mt-1 flex items-end justify-between gap-3">
            <h2 className="text-lg font-semibold tracking-tight">{event.title}</h2>
            <p className="nums text-sm text-muted">{now == null ? "" : formatWhen(event.startsAt, now)}</p>
          </div>
          <p className="nums mt-1 text-3xl font-medium tracking-tight">
            {now == null ? "—" : formatCountdown(event.startsAt, now)}
          </p>
          <div className="mt-4 grid grid-cols-4 gap-2">
            <Count label="In" value={counts.inn} />
            <Count label="Out" value={counts.out} />
            <Count label="Maybe" value={counts.maybe} />
            <Count label="Silent" value={counts.silent} />
          </div>
          <p className="mt-3 text-sm text-muted">{KIND_INFO[event.kind].rule || event.note}</p>
          {counts.silent > 0 ? (
            <p className="mt-2 text-sm text-fg">No reply: {namesFor(event, members, "silent").join(", ")}</p>
          ) : null}
          <div className="mt-4 flex flex-wrap gap-2">
            <Button variant="primary" onClick={() => onOpenOps("events", event.id)}>
              Take attendance
            </Button>
            <Button onClick={() => onTab("orders")}>Draft orders</Button>
          </div>
        </Card>
      ) : (
        <Card className="mb-3">
          <h2 className="text-lg font-semibold">No operations scheduled</h2>
          <p className="mt-1 text-sm text-muted">Add a bear, fortress, or mobilization from Ops.</p>
          <Button className="mt-4" variant="primary" onClick={() => onOpenOps("events")}>
            Open ops
          </Button>
        </Card>
      )}

      <div className="grid gap-3 md:grid-cols-2">
        <Card>
          <h2 className="text-sm font-semibold">Officer loop</h2>
          <ul className="mt-2">
            {duties.map((duty) => (
              <li key={duty.id} className="border-b border-line last:border-b-0">
                <button
                  type="button"
                  onClick={() => toggleDuty(duty.id)}
                  className="flex min-h-11 w-full items-center gap-3 py-2 text-left"
                >
                  <span
                    className={
                      duty.done
                        ? "grid h-5 w-5 shrink-0 place-items-center rounded-sm bg-accent text-accent-fg"
                        : "h-5 w-5 shrink-0 rounded-sm border border-line"
                    }
                    aria-hidden="true"
                  >
                    {duty.done ? (
                      <svg viewBox="0 0 16 16" className="h-3 w-3" fill="none" stroke="currentColor" strokeWidth="2">
                        <path d="M3 8.5 6.2 12 13 4" />
                      </svg>
                    ) : null}
                  </span>
                  <span className={duty.done ? "text-sm text-muted line-through" : "text-sm text-fg"}>{duty.label}</span>
                </button>
              </li>
            ))}
          </ul>
        </Card>

        <div className="grid gap-3">
          <Card>
            <div className="flex items-start justify-between gap-3">
              <div>
                <h2 className="text-sm font-semibold">Research next</h2>
                <p className="mt-1 text-sm text-fg">
                  {rec.node ? `${rec.node.name} ${rec.node.level}/${rec.node.max}` : "Tree complete"}
                </p>
                <p className="mt-1 text-xs text-muted">{rec.why}</p>
              </div>
              <Button onClick={() => onTab("tech")}>Tech</Button>
            </div>
            <div className="mt-3">
              <div className="mb-1 flex justify-between text-xs text-muted">
                <span>Donations today</span>
                <span className="nums">
                  {alliance.donations.toLocaleString()} / {alliance.donationGoal.toLocaleString()}
                </span>
              </div>
              <div className="h-1.5 overflow-hidden rounded-sm bg-bg">
                <div className="h-full bg-accent" style={{ width: `${donatePct}%` }} />
              </div>
            </div>
          </Card>

          <Card>
            <div className="mb-2 flex items-center justify-between gap-3">
              <h2 className="text-sm font-semibold">Rallies</h2>
              <Button variant="quiet" onClick={() => onOpenOps("rallies")}>
                Board
              </Button>
            </div>
            {openRallies.length === 0 ? (
              <p className="text-sm text-muted">No open rallies.</p>
            ) : (
              <ul className="space-y-3">
                {openRallies.map((rally) => (
                  <li key={rally.id} className="flex items-baseline justify-between gap-3">
                    <div className="min-w-0">
                      <p className="truncate text-sm font-medium">{rally.target}</p>
                      <p className="truncate text-xs text-muted">
                        {memberName(members, rally.captainId)} · {rally.hero || "No hero set"}
                      </p>
                    </div>
                    <p className="nums shrink-0 text-xs text-muted">
                      {rally.filled}/{rally.slots}
                      {now == null ? "" : ` · ${formatCountdown(rally.startsAt, now)}`}
                    </p>
                  </li>
                ))}
              </ul>
            )}
          </Card>
        </div>
      </div>

      {review.length > 0 ? (
        <Card className="mt-3">
          <h2 className="text-sm font-semibold">Roster review</h2>
          <ul className="mt-2 space-y-2">
            {review.map((m) => (
              <li key={m.id} className="flex items-baseline justify-between gap-3 text-sm">
                <span className="min-w-0 truncate">
                  {m.name}
                  <span className="text-muted"> · {m.rank} · {formatPower(m.power)}</span>
                </span>
                <span className="shrink-0 text-xs text-faint">{m.note || "No note"}</span>
              </li>
            ))}
          </ul>
        </Card>
      ) : null}

      <p className="mt-4 text-xs text-faint">
        Saved on this device. Export a copy from alliance settings if you switch phones. Sample data is Northwatch — replace it with yours.
      </p>
      <AllianceSheet open={settings} onClose={() => setSettings(false)} />
    </div>
  );
}

function Count({ label, value }: { label: string; value: number }) {
  return (
    <div className="rounded-sm bg-bg px-2 py-2">
      <div className="nums text-lg font-medium">{value}</div>
      <div className="text-xs text-muted">{label}</div>
    </div>
  );
}
