import { useRef, useState } from "react";
import { Button, Field, Sheet, controlClass } from "@/components/ui";
import { PHASES, normalizeDesk, type Phase } from "@/lib/wos/model";
import { useDesk } from "@/lib/wos/store";

export function AllianceSheet({ open, onClose }: { open: boolean; onClose: () => void }) {
  const alliance = useDesk((s) => s.alliance);
  const updateAlliance = useDesk((s) => s.updateAlliance);
  const replaceAll = useDesk((s) => s.replaceAll);
  const resetDemo = useDesk((s) => s.resetDemo);
  const fileRef = useRef<HTMLInputElement>(null);
  const [error, setError] = useState("");
  const [confirmReset, setConfirmReset] = useState(false);

  function exportDesk() {
    const { alliance: a, members, events, rallies, tech, forts, duties } = useDesk.getState();
    const blob = new Blob([JSON.stringify({ alliance: a, members, events, rallies, tech, forts, duties }, null, 2)], {
      type: "application/json",
    });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `${a.tag || "alliance"}-frostline.json`;
    link.click();
    URL.revokeObjectURL(url);
  }

  async function onFile(file: File | undefined) {
    if (!file) return;
    setError("");
    try {
      const parsed: unknown = JSON.parse(await file.text());
      const data = normalizeDesk(parsed);
      if (!data) {
        setError("That file is not a Frostline desk.");
        return;
      }
      replaceAll(data);
      onClose();
    } catch {
      setError("Could not read that file.");
    }
  }

  return (
    <Sheet open={open} title="Alliance" onClose={onClose}>
      <Field label="Name">
        <input className={controlClass} value={alliance.name} maxLength={40} onChange={(e) => updateAlliance({ name: e.target.value })} />
      </Field>
      <div className="grid grid-cols-2 gap-3">
        <Field label="Tag">
          <input className={controlClass} value={alliance.tag} maxLength={6} onChange={(e) => updateAlliance({ tag: e.target.value.toUpperCase() })} />
        </Field>
        <Field label="State">
          <input className={controlClass} value={alliance.server} maxLength={12} onChange={(e) => updateAlliance({ server: e.target.value })} />
        </Field>
      </div>
      <div className="grid grid-cols-2 gap-3">
        <Field label="Level">
          <input
            className={controlClass}
            inputMode="numeric"
            value={alliance.level}
            onChange={(e) => updateAlliance({ level: clampNum(e.target.value, 1, 11, alliance.level) })}
          />
        </Field>
        <Field label="Roster cap">
          <input
            className={controlClass}
            inputMode="numeric"
            value={alliance.cap}
            onChange={(e) => updateAlliance({ cap: clampNum(e.target.value, 10, 120, alliance.cap) })}
          />
        </Field>
      </div>
      <Field label="Phase">
        <select
          className={controlClass}
          value={alliance.phase}
          onChange={(e) => updateAlliance({ phase: e.target.value as Phase })}
        >
          {PHASES.map((p) => (
            <option key={p.id} value={p.id}>
              {p.label}
            </option>
          ))}
        </select>
      </Field>
      <p className="mb-3 text-xs text-muted">{PHASES.find((p) => p.id === alliance.phase)?.hint}</p>
      <div className="grid grid-cols-2 gap-3">
        <Field label="Bear trap level">
          <input
            className={controlClass}
            inputMode="numeric"
            value={alliance.bearLevel}
            onChange={(e) => updateAlliance({ bearLevel: clampNum(e.target.value, 1, 20, alliance.bearLevel) })}
          />
        </Field>
        <Field label="Donation goal">
          <input
            className={controlClass}
            inputMode="numeric"
            value={alliance.donationGoal}
            onChange={(e) => updateAlliance({ donationGoal: clampNum(e.target.value, 0, 9_999_999, alliance.donationGoal) })}
          />
        </Field>
      </div>
      <div className="mt-2 grid grid-cols-2 gap-2">
        <Button onClick={exportDesk}>Export</Button>
        <Button onClick={() => fileRef.current?.click()}>Import</Button>
      </div>
      <input
        ref={fileRef}
        type="file"
        accept="application/json"
        className="sr-only"
        onChange={(e) => {
          void onFile(e.target.files?.[0]);
          e.target.value = "";
        }}
      />
      {error ? <p className="mt-2 text-sm text-danger">{error}</p> : null}
      <div className="mt-4 border-t border-line pt-4">
        {confirmReset ? (
          <div className="flex gap-2">
            <Button
              variant="danger"
              className="flex-1"
              onClick={() => {
                resetDemo();
                setConfirmReset(false);
                onClose();
              }}
            >
              Replace with sample
            </Button>
            <Button className="flex-1" onClick={() => setConfirmReset(false)}>
              Cancel
            </Button>
          </div>
        ) : (
          <Button variant="quiet" onClick={() => setConfirmReset(true)}>
            Reset to Northwatch sample
          </Button>
        )}
      </div>
    </Sheet>
  );
}

function clampNum(raw: string, min: number, max: number, prev: number) {
  if (raw.trim() === "") return min;
  const n = Number(raw);
  if (!Number.isFinite(n)) return prev;
  return Math.min(max, Math.max(min, Math.round(n)));
}
