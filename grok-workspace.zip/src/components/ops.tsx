import { useEffect, useState } from "react";
import { Plus } from "lucide-react";
import { clsx } from "clsx";
import { Button, Field, Segment, Sheet, ViewHeader, areaClass, controlClass } from "@/components/ui";
import {
  FORT_STATUS,
  KIND_INFO,
  RALLY_STATUS,
  formatCountdown,
  formatWhen,
  fromLocalInput,
  memberName,
  nextEvent,
  sortedMembers,
  toLocalInput,
  defaultStart,
  type AllianceEvent,
  type EventKind,
  type FortStatus,
  type Rally,
  type RallyStatus,
  type Rsvp,
} from "@/lib/wos/model";
import { newId, useDesk } from "@/lib/wos/store";

export type OpsSection = "events" | "rallies" | "forts";

const SECTIONS: { id: OpsSection; label: string }[] = [
  { id: "events", label: "Events" },
  { id: "rallies", label: "Rallies" },
  { id: "forts", label: "Forts" },
];

const KINDS = (Object.keys(KIND_INFO) as EventKind[]).filter((k) => k !== "custom");

export function Ops({
  now,
  section,
  onSection,
  focusId,
}: {
  now: number;
  section: OpsSection;
  onSection: (section: OpsSection) => void;
  focusId: string | null;
}) {
  return (
    <div>
      <ViewHeader kicker="Operations" title="War board" />
      <Segment label="Operations" value={section} options={SECTIONS} onChange={onSection} />
      {section === "events" ? <Events now={now} focusId={focusId} /> : null}
      {section === "rallies" ? <Rallies now={now} /> : null}
      {section === "forts" ? <Forts /> : null}
    </div>
  );
}

function Events({ now, focusId }: { now: number; focusId: string | null }) {
  const events = useDesk((s) => s.events);
  const members = useDesk((s) => s.members);
  const addEvent = useDesk((s) => s.addEvent);
  const updateEvent = useDesk((s) => s.updateEvent);
  const removeEvent = useDesk((s) => s.removeEvent);
  const setRsvp = useDesk((s) => s.setRsvp);
  const cycleMemberLane = useDesk((s) => s.cycleMemberLane);
  const autoLanes = useDesk((s) => s.autoLanes);
  const sorted = [...events].sort((a, b) => a.startsAt - b.startsAt);
  const [selected, setSelected] = useState<string | null>(focusId ?? nextEvent(events, now)?.id ?? null);
  const [adding, setAdding] = useState(false);
  const [armRemove, setArmRemove] = useState(false);

  useEffect(() => {
    if (focusId) setSelected(focusId);
  }, [focusId]);

  useEffect(() => {
    setArmRemove(false);
  }, [selected]);

  const event = sorted.find((e) => e.id === selected) ?? sorted[0] ?? null;

  return (
    <div>
      <div className="mb-3 flex items-center justify-between gap-3">
        <p className="text-sm text-muted">Mark who is in. Tap again to clear.</p>
        <Button
          variant="primary"
          onClick={() => setAdding(true)}
        >
          <Plus size={16} />
          Event
        </Button>
      </div>
      <div className="flex gap-2 overflow-x-auto pb-1">
        {sorted.map((item) => (
          <button
            key={item.id}
            type="button"
            onClick={() => setSelected(item.id)}
            className={clsx(
              "press h-11 shrink-0 rounded-sm px-3 text-sm font-medium",
              event?.id === item.id ? "bg-accent text-accent-fg" : "border border-line bg-surface text-muted",
            )}
          >
            {item.title}
          </button>
        ))}
      </div>
      {event ? (
        <article className="mt-3 rounded-xl border border-line bg-surface p-4">
          <div className="flex items-start justify-between gap-3">
            <div>
              <h2 className="text-lg font-semibold tracking-tight">{event.title}</h2>
              <p className="text-sm text-muted">
                {formatWhen(event.startsAt, now)} · {formatCountdown(event.startsAt, now)}
              </p>
            </div>
            <Button
              variant="quiet"
              onClick={() => {
                if (!armRemove) {
                  setArmRemove(true);
                  return;
                }
                removeEvent(event.id);
                setSelected(null);
                setArmRemove(false);
              }}
            >
              {armRemove ? "Confirm remove" : "Remove"}
            </Button>
          </div>
          <p className="mt-2 text-xs text-faint">{(KIND_INFO[event.kind] ?? KIND_INFO.custom).cadence}</p>
          {(KIND_INFO[event.kind] ?? KIND_INFO.custom).rule ? (
            <p className="mt-2 text-sm text-muted">{(KIND_INFO[event.kind] ?? KIND_INFO.custom).rule}</p>
          ) : null}
          <Field label="Call note">
            <textarea
              className={areaClass}
              value={event.note}
              maxLength={240}
              onChange={(e) => updateEvent(event.id, { note: e.target.value })}
            />
          </Field>
          <Field label="Starts">
            <input
              type="datetime-local"
              className={controlClass}
              value={toLocalInput(event.startsAt)}
              onChange={(e) => updateEvent(event.id, { startsAt: fromLocalInput(e.target.value) })}
            />
          </Field>
          <h3 className="mb-1 text-sm font-semibold">Attendance</h3>
          <ul className="divide-y divide-line">
            {sortedMembers(members).map((m) => {
              const value = event.rsvp[m.id];
              return (
                <li key={m.id} className="py-3">
                  <div className="mb-2 flex items-baseline justify-between gap-3">
                    <p className="truncate text-sm font-medium">{m.name}</p>
                    <p className="nums shrink-0 text-xs text-faint">{m.rank}</p>
                  </div>
                  <div className="grid grid-cols-3 gap-2">
                    {(["in", "out", "maybe"] as Rsvp[]).map((option) => (
                      <button
                        key={option}
                        type="button"
                        aria-pressed={value === option}
                        onClick={() => setRsvp(event.id, m.id, option)}
                        className={clsx(
                          "press h-11 rounded-sm text-sm font-medium",
                          value === option ? "bg-accent text-accent-fg" : "bg-bg text-muted",
                        )}
                      >
                        {option === "in" ? "In" : option === "out" ? "Out" : "Maybe"}
                      </button>
                    ))}
                  </div>
                </li>
              );
            })}
          </ul>
          {event.kind === "championship" ? (
            <Lanes event={event} onCycle={(id) => cycleMemberLane(event.id, id)} onBalance={() => autoLanes(event.id)} />
          ) : null}
        </article>
      ) : (
        <p className="mt-4 text-sm text-muted">No events yet.</p>
      )}
      <Sheet open={adding} title="Add event" onClose={() => setAdding(false)}>
        <div className="grid gap-2">
          {KINDS.map((kind) => (
            <button
              key={kind}
              type="button"
              className="press rounded-lg border border-line bg-bg px-3 py-3 text-left"
              onClick={() => {
                const created: AllianceEvent = {
                  id: newId(),
                  kind,
                  title: KIND_INFO[kind].label,
                  startsAt: defaultStart(kind, now),
                  note: "",
                  rsvp: {},
                  lanes: kind === "championship" ? { left: [], mid: [], right: [] } : undefined,
                };
                addEvent(created);
                setSelected(created.id);
                setAdding(false);
              }}
            >
              <span className="block text-sm font-medium">{KIND_INFO[kind].label}</span>
              <span className="block text-xs text-muted">{KIND_INFO[kind].cadence}</span>
            </button>
          ))}
        </div>
      </Sheet>
    </div>
  );
}

function Lanes({
  event,
  onCycle,
  onBalance,
}: {
  event: AllianceEvent;
  onCycle: (id: string) => void;
  onBalance: () => void;
}) {
  const members = useDesk((s) => s.members);
  const lanes = event.lanes ?? { left: [], mid: [], right: [] };
  const assigned = new Set([...lanes.left, ...lanes.mid, ...lanes.right]);
  const pool = sortedMembers(members).filter((m) => event.rsvp[m.id] === "in");
  return (
    <div className="mt-4 border-t border-line pt-4">
      <div className="mb-3 flex items-center justify-between gap-3">
        <h3 className="text-sm font-semibold">Lanes</h3>
        <Button onClick={onBalance}>Balance by power</Button>
      </div>
      <p className="mb-3 text-xs text-muted">Tap a name to move it: mid, left, right, then off the card.</p>
      <div className="grid gap-2 sm:grid-cols-3">
        {(["mid", "left", "right"] as const).map((key) => (
          <div key={key} className="rounded-md bg-bg p-3">
            <p className="text-xs font-medium capitalize text-muted">{key}</p>
            <ul className="mt-2 space-y-1">
              {lanes[key].length === 0 ? <li className="text-sm text-faint">Empty</li> : null}
              {lanes[key].map((id) => (
                <li key={id}>
                  <button type="button" className="h-11 w-full text-left text-sm font-medium" onClick={() => onCycle(id)}>
                    {memberName(members, id)}
                  </button>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
      <div className="mt-3 flex flex-wrap gap-2">
        {pool
          .filter((m) => !assigned.has(m.id))
          .map((m) => (
            <button
              key={m.id}
              type="button"
              onClick={() => onCycle(m.id)}
              className="press h-11 rounded-sm border border-line px-3 text-sm"
            >
              {m.name}
            </button>
          ))}
      </div>
    </div>
  );
}

function Rallies({ now }: { now: number }) {
  const rallies = useDesk((s) => s.rallies);
  const members = useDesk((s) => s.members);
  const addRally = useDesk((s) => s.addRally);
  const updateRally = useDesk((s) => s.updateRally);
  const removeRally = useDesk((s) => s.removeRally);
  const [editing, setEditing] = useState<Rally | null>(null);
  const [isNew, setIsNew] = useState(false);
  const sorted = [...rallies].sort((a, b) => a.startsAt - b.startsAt);

  return (
    <div>
      <div className="mb-3 flex justify-end">
        <Button
          variant="primary"
          onClick={() => {
            setIsNew(true);
            setEditing({
              id: newId(),
              target: "Polar Terror 6",
              captainId: members.find((m) => m.role === "captain")?.id ?? members[0]?.id ?? "",
              startsAt: now + 60 * 60 * 1000,
              slots: 8,
              filled: 1,
              hero: "",
              status: "forming",
            });
          }}
        >
          <Plus size={16} />
          Rally
        </Button>
      </div>
      <ul className="space-y-2">
        {sorted.length === 0 ? <li className="text-sm text-muted">No rallies on the board.</li> : null}
        {sorted.map((rally) => (
          <li key={rally.id}>
            <button
              type="button"
              onClick={() => {
                setIsNew(false);
                setEditing(rally);
              }}
              className="w-full rounded-xl border border-line bg-surface p-4 text-left"
            >
              <div className="flex items-baseline justify-between gap-3">
                <h2 className="text-base font-semibold">{rally.target}</h2>
                <span className="nums text-xs text-muted">
                  {rally.filled}/{rally.slots}
                </span>
              </div>
              <p className="mt-1 text-sm text-muted">
                {memberName(members, rally.captainId)} · {rally.status} · {formatWhen(rally.startsAt, now)}
              </p>
              {rally.hero ? <p className="mt-1 text-xs text-faint">First slot: {rally.hero}</p> : null}
              {/bear/i.test(rally.target) ? (
                <p className="mt-2 text-xs text-muted">{KIND_INFO.bear.rule}</p>
              ) : null}
            </button>
          </li>
        ))}
      </ul>
      <RallySheet
        rally={editing}
        isNew={isNew}
        onClose={() => setEditing(null)}
        onSave={(rally) => {
          if (isNew) addRally(rally);
          else updateRally(rally.id, rally);
          setEditing(null);
        }}
        onRemove={(id) => {
          removeRally(id);
          setEditing(null);
        }}
      />
    </div>
  );
}

function RallySheet({
  rally,
  isNew,
  onClose,
  onSave,
  onRemove,
}: {
  rally: Rally | null;
  isNew: boolean;
  onClose: () => void;
  onSave: (rally: Rally) => void;
  onRemove: (id: string) => void;
}) {
  return (
    <Sheet open={!!rally} title={isNew ? "New rally" : "Rally"} onClose={onClose}>
      {rally ? <RallyForm key={rally.id} rally={rally} isNew={isNew} onSave={onSave} onRemove={onRemove} /> : null}
    </Sheet>
  );
}

function RallyForm({
  rally,
  isNew,
  onSave,
  onRemove,
}: {
  rally: Rally;
  isNew: boolean;
  onSave: (rally: Rally) => void;
  onRemove: (id: string) => void;
}) {
  const members = useDesk((s) => s.members);
  const [draft, setDraft] = useState(rally);
  const [confirm, setConfirm] = useState(false);
  const patch = (p: Partial<Rally>) => setDraft((d) => ({ ...d, ...p }));
  const captains = sortedMembers(members);
  return (
    <>
      <Field label="Target">
        <input
          className={controlClass}
          list="rally-targets"
          value={draft.target}
          maxLength={40}
          onChange={(e) => patch({ target: e.target.value })}
        />
        <datalist id="rally-targets">
          {["Bear", "Polar Terror 5", "Polar Terror 6", "Polar Terror 7", "Polar Terror 8", "Cryptid", "City"].map(
            (t) => (
              <option key={t} value={t} />
            ),
          )}
        </datalist>
      </Field>
      <Field label="Captain">
        <select className={controlClass} value={draft.captainId} onChange={(e) => patch({ captainId: e.target.value })}>
          {captains.map((m) => (
            <option key={m.id} value={m.id}>
              {m.name} · {m.rank}
            </option>
          ))}
        </select>
      </Field>
      <Field label="Starts">
        <input
          type="datetime-local"
          className={controlClass}
          value={toLocalInput(draft.startsAt)}
          onChange={(e) => patch({ startsAt: fromLocalInput(e.target.value) })}
        />
      </Field>
      <div className="grid grid-cols-2 gap-3">
        <Field label="Filled">
          <input
            className={controlClass}
            inputMode="numeric"
            value={draft.filled}
            onChange={(e) => {
              const n = Number(e.target.value);
              if (Number.isFinite(n)) patch({ filled: Math.max(0, Math.min(draft.slots, Math.round(n))) });
            }}
          />
        </Field>
        <Field label="Slots">
          <input
            className={controlClass}
            inputMode="numeric"
            value={draft.slots}
            onChange={(e) => {
              const n = Number(e.target.value);
              if (Number.isFinite(n)) {
                const slots = Math.max(1, Math.min(20, Math.round(n)));
                patch({ slots, filled: Math.min(draft.filled, slots) });
              }
            }}
          />
        </Field>
      </div>
      <Field label="First-slot hero">
        <input
          className={controlClass}
          value={draft.hero}
          maxLength={48}
          placeholder="Jessie"
          onChange={(e) => patch({ hero: e.target.value })}
        />
      </Field>
      <Field label="Status">
        <select
          className={controlClass}
          value={draft.status}
          onChange={(e) => patch({ status: e.target.value as RallyStatus })}
        >
          {RALLY_STATUS.map((s) => (
            <option key={s} value={s}>
              {s}
            </option>
          ))}
        </select>
      </Field>
      {/bear/i.test(draft.target) ? <p className="mb-3 text-xs text-muted">{KIND_INFO.bear.rule}</p> : null}
      <Button variant="primary" className="w-full" disabled={!draft.target.trim() || !draft.captainId} onClick={() => onSave({ ...draft, target: draft.target.trim() })}>
        Save rally
      </Button>
      {!isNew ? (
        confirm ? (
          <div className="mt-2 grid grid-cols-2 gap-2">
            <Button variant="danger" onClick={() => onRemove(draft.id)}>
              Confirm remove
            </Button>
            <Button onClick={() => setConfirm(false)}>Cancel</Button>
          </div>
        ) : (
          <Button variant="quiet" className="mt-2 w-full" onClick={() => setConfirm(true)}>
            Remove rally
          </Button>
        )
      ) : null}
    </>
  );
}

function Forts() {
  const forts = useDesk((s) => s.forts);
  const cycleFort = useDesk((s) => s.cycleFort);
  return (
    <div>
      <p className="mb-3 text-sm text-muted">Tap a structure to cycle Open, Target, Held, Enemy. Hold a target for 30 minutes on Friday.</p>
      <ul className="grid gap-2 sm:grid-cols-2">
        {forts.map((fort) => (
          <li key={fort.id}>
            <button
              type="button"
              onClick={() => cycleFort(fort.id)}
              className="press flex min-h-16 w-full items-center justify-between gap-3 rounded-xl border border-line bg-surface px-3 py-3 text-left"
            >
              <span className="min-w-0">
                <span className="block truncate text-sm font-medium">{fort.name}</span>
                <span className="block truncate text-xs text-muted">{fort.buff}</span>
              </span>
              <StatusPill status={fort.status} />
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}

function StatusPill({ status }: { status: FortStatus }) {
  const label = FORT_STATUS.find((s) => s.id === status)?.label ?? status;
  const tone =
    status === "held" ? "text-ok" : status === "target" ? "text-fg" : status === "enemy" ? "text-danger" : "text-faint";
  return <span className={clsx("shrink-0 text-xs font-medium", tone)}>{label}</span>;
}
