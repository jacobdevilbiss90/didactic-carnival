import { useMemo, useState } from "react";
import { Check, Copy } from "lucide-react";
import { clsx } from "clsx";
import { Button, Field, ViewHeader, areaClass } from "@/components/ui";
import { buildPing, type PingKind } from "@/lib/wos/model";
import { useDesk } from "@/lib/wos/store";

const PINGS: { id: PingKind; label: string }[] = [
  { id: "full", label: "Full orders" },
  { id: "bear", label: "Bear" },
  { id: "silent", label: "Silent" },
  { id: "donate", label: "Donate" },
  { id: "forts", label: "Forts" },
  { id: "lanes", label: "Lanes" },
];

export function Orders({ now }: { now: number }) {
  const data = useDesk();
  const updateAlliance = useDesk((s) => s.updateAlliance);
  const [kind, setKind] = useState<PingKind>("full");
  const [copied, setCopied] = useState(false);
  const ping = useMemo(() => buildPing(kind, data, now), [kind, data, now]);

  async function copy() {
    const text = ping.body;
    try {
      await navigator.clipboard.writeText(text);
    } catch {
      const area = document.createElement("textarea");
      area.value = text;
      document.body.appendChild(area);
      area.select();
      document.execCommand("copy");
      area.remove();
    }
    setCopied(true);
    window.setTimeout(() => setCopied(false), 1600);
  }

  return (
    <div>
      <ViewHeader
        kicker="Chat copy"
        title="Orders"
        action={
          <Button variant="primary" onClick={() => void copy()}>
            {copied ? <Check size={16} /> : <Copy size={16} />}
            {copied ? "Copied" : "Copy"}
          </Button>
        }
      />
      <p className="mb-3 text-sm text-muted">
        Paste into alliance chat or Discord. The text follows the roster, attendance, and targets on this desk.
      </p>
      <div className="mb-3 flex gap-2 overflow-x-auto pb-1">
        {PINGS.map((item) => (
          <button
            key={item.id}
            type="button"
            onClick={() => {
              setKind(item.id);
              setCopied(false);
            }}
            className={clsx(
              "press h-11 shrink-0 rounded-sm px-3 text-sm font-medium",
              kind === item.id ? "bg-accent text-accent-fg" : "border border-line bg-surface text-muted",
            )}
          >
            {item.label}
          </button>
        ))}
      </div>
      <pre className="nums overflow-x-auto rounded-xl border border-line bg-surface p-4 text-xs leading-relaxed whitespace-pre-wrap text-fg">
        {ping.body}
      </pre>
      <Field label="Standing note, included in full orders">
        <textarea
          className={areaClass}
          maxLength={400}
          value={data.alliance.ordersNote}
          onChange={(e) => updateAlliance({ ordersNote: e.target.value })}
        />
      </Field>
    </div>
  );
}
