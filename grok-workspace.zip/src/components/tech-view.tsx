import { Button, Card, ViewHeader, controlClass } from "@/components/ui";
import { PHASES, TREE_LABEL, recommendation, treeProgress, type Phase, type Tree } from "@/lib/wos/model";
import { useDesk } from "@/lib/wos/store";
import { clsx } from "clsx";

const TREES: Tree[] = ["growth", "territory", "battle"];

export function TechView() {
  const alliance = useDesk((s) => s.alliance);
  const tech = useDesk((s) => s.tech);
  const updateAlliance = useDesk((s) => s.updateAlliance);
  const setTechLevel = useDesk((s) => s.setTechLevel);
  const rec = recommendation(tech, alliance.phase);
  const donatePct = alliance.donationGoal
    ? Math.min(100, Math.round((alliance.donations / alliance.donationGoal) * 100))
    : 0;

  return (
    <div>
      <ViewHeader kicker="Alliance tech" title="Research" />
      <Card className="mb-4">
        <p className="text-xs font-medium text-faint">Next for this phase</p>
        <h2 className="mt-1 text-lg font-semibold tracking-tight">
          {rec.node ? rec.node.name : "Nothing open"}
        </h2>
        <p className="mt-1 text-sm text-muted">{rec.why}</p>
        {rec.node ? (
          <p className="nums mt-2 text-sm text-fg">
            {rec.node.level}/{rec.node.max} · {rec.node.effect}
          </p>
        ) : null}
        <div className="mt-4">
          <div className="mb-1 flex justify-between text-xs text-muted">
            <span>Donated today</span>
            <span className="nums">
              {alliance.donations.toLocaleString()} / {alliance.donationGoal.toLocaleString()}
            </span>
          </div>
          <div className="h-1.5 overflow-hidden rounded-sm bg-bg">
            <div className="h-full bg-accent" style={{ width: `${donatePct}%` }} />
          </div>
          <label className="mt-3 block">
            <span className="mb-1 block text-xs font-medium text-muted">Update today's donations</span>
            <input
              className={controlClass}
              inputMode="numeric"
              value={alliance.donations}
              onChange={(e) => {
                const n = Number(e.target.value);
                if (e.target.value === "") updateAlliance({ donations: 0 });
                else if (Number.isFinite(n) && n >= 0) updateAlliance({ donations: Math.round(n) });
              }}
            />
          </label>
        </div>
      </Card>

      <div className="mb-4 grid grid-cols-3 gap-2">
        {PHASES.map((phase) => (
          <button
            key={phase.id}
            type="button"
            onClick={() => updateAlliance({ phase: phase.id as Phase })}
            className={clsx(
              "press h-11 rounded-sm text-sm font-medium",
              alliance.phase === phase.id ? "bg-accent text-accent-fg" : "border border-line bg-surface text-muted",
            )}
          >
            {phase.label}
          </button>
        ))}
      </div>
      <p className="mb-4 text-sm text-muted">{PHASES.find((p) => p.id === alliance.phase)?.hint}</p>

      <div className="space-y-5">
        {TREES.map((tree) => {
          const progress = treeProgress(tech, tree);
          const nodes = tech.filter((n) => n.tree === tree);
          return (
            <section key={tree}>
              <div className="mb-2 flex items-baseline justify-between gap-3">
                <h2 className="text-sm font-semibold">{TREE_LABEL[tree]}</h2>
                <p className="nums text-xs text-muted">
                  {progress.cur}/{progress.max} · {progress.pct}%
                </p>
              </div>
              <div className="mb-2 h-1.5 overflow-hidden rounded-sm bg-raised">
                <div className="h-full bg-accent" style={{ width: `${progress.pct}%` }} />
              </div>
              <ul className="divide-y divide-line rounded-xl border border-line bg-surface">
                {nodes.map((node) => {
                  const next = rec.node?.id === node.id;
                  return (
                    <li key={node.id} className="flex items-center gap-3 px-3 py-3">
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-sm font-medium">
                          {node.name}
                          {next ? <span className="ml-2 text-xs font-medium text-faint">Next</span> : null}
                        </p>
                        <p className="truncate text-xs text-muted">{node.effect}</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <Button
                          className="w-11 px-0"
                          aria-label={`Decrease ${node.name}`}
                          disabled={node.level <= 0}
                          onClick={() => setTechLevel(node.id, node.level - 1)}
                        >
                          −
                        </Button>
                        <span className="nums w-10 text-center text-sm">
                          {node.level}/{node.max}
                        </span>
                        <Button
                          className="w-11 px-0"
                          aria-label={`Increase ${node.name}`}
                          disabled={node.level >= node.max}
                          onClick={() => setTechLevel(node.id, node.level + 1)}
                        >
                          +
                        </Button>
                      </div>
                    </li>
                  );
                })}
              </ul>
            </section>
          );
        })}
      </div>
    </div>
  );
}
