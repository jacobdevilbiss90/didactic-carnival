import { Compass, Layers, ScrollText, Swords, Users } from "lucide-react";
import { useEffect, useState } from "react";
import { clsx } from "clsx";
import { Brief } from "@/components/brief";
import { Ops, type OpsSection } from "@/components/ops";
import { Orders } from "@/components/orders";
import { Roster } from "@/components/roster";
import { TechView } from "@/components/tech-view";
import { useDesk } from "@/lib/wos/store";

export type Tab = "brief" | "roster" | "ops" | "tech" | "orders";

const TABS: { id: Tab; label: string; icon: typeof Compass }[] = [
  { id: "brief", label: "Brief", icon: Compass },
  { id: "roster", label: "Roster", icon: Users },
  { id: "ops", label: "Ops", icon: Swords },
  { id: "tech", label: "Tech", icon: Layers },
  { id: "orders", label: "Orders", icon: ScrollText },
];

export function useNow(ms = 30_000) {
  const [now, setNow] = useState<number | null>(null);
  useEffect(() => {
    const tick = () => setNow(Date.now());
    tick();
    const id = window.setInterval(tick, ms);
    return () => window.clearInterval(id);
  }, [ms]);
  return now;
}

export function Desk() {
  const [tab, setTab] = useState<Tab>("brief");
  const [section, setSection] = useState<OpsSection>("events");
  const [eventFocus, setEventFocus] = useState<string | null>(null);
  const alliance = useDesk((s) => s.alliance);
  const resetDemo = useDesk((s) => s.resetDemo);
  const now = useNow();

  useEffect(() => {
    void useDesk.persist.rehydrate();
  }, []);

  function openOps(next: OpsSection, eventId?: string) {
    setSection(next);
    if (eventId) setEventFocus(eventId);
    setTab("ops");
  }

  return (
    <div className="min-h-screen bg-bg text-fg">
      <div className="mx-auto flex max-w-6xl">
        <aside className="sticky top-0 hidden h-screen w-56 shrink-0 flex-col border-r border-line md:flex">
          <div className="px-4 pt-6 pb-4">
            <p className="text-xs font-medium text-faint">Frostline</p>
            <p className="truncate text-base font-semibold tracking-tight">{alliance?.name ?? "Alliance desk"}</p>
          </div>
          <nav className="flex flex-col gap-1 px-3" aria-label="Sections">
            {TABS.map((item) => {
              const Icon = item.icon;
              const on = tab === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  aria-current={on ? "page" : undefined}
                  onClick={() => setTab(item.id)}
                  className={clsx(
                    "press flex h-11 items-center gap-3 rounded-md px-3 text-sm font-medium",
                    on ? "bg-raised text-fg" : "text-muted",
                  )}
                >
                  <Icon size={18} strokeWidth={1.75} />
                  {item.label}
                </button>
              );
            })}
          </nav>
        </aside>
        <main className="pb-nav min-w-0 flex-1 px-4 pt-5 md:px-8 md:pt-8">
          <div className="rise w-full max-w-3xl">
            {!alliance?.name ? (
              <div className="rounded-xl border border-line bg-surface p-4">
                <h1 className="text-xl font-semibold">Desk data is unreadable</h1>
                <p className="mt-2 text-sm text-muted">Restore the sample alliance and start again.</p>
                <button
                  type="button"
                  className="press mt-4 h-11 rounded-sm bg-accent px-3 text-sm font-medium text-accent-fg"
                  onClick={resetDemo}
                >
                  Restore sample
                </button>
              </div>
            ) : (
              <>
                {tab === "brief" && <Brief now={now} onOpenOps={openOps} onTab={setTab} />}
                {tab === "roster" && <Roster />}
                {tab === "ops" && (
                  <Ops now={now ?? Date.now()} section={section} onSection={setSection} focusId={eventFocus} />
                )}
                {tab === "tech" && <TechView />}
                {tab === "orders" && <Orders now={now ?? Date.now()} />}
              </>
            )}
          </div>
        </main>
      </div>
      <nav
        className="nav-safe fixed inset-x-0 bottom-0 z-30 border-t border-line bg-surface md:hidden"
        aria-label="Sections"
      >
        <div className="grid grid-cols-5">
          {TABS.map((item) => {
            const Icon = item.icon;
            const on = tab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                aria-current={on ? "page" : undefined}
                onClick={() => setTab(item.id)}
                className={clsx(
                  "flex h-16 flex-col items-center justify-center gap-1 text-xs font-medium",
                  on ? "text-fg" : "text-faint",
                )}
              >
                <Icon size={18} strokeWidth={1.75} />
                {item.label}
              </button>
            );
          })}
        </div>
      </nav>
    </div>
  );
}
