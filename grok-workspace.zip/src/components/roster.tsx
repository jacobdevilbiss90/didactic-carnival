import { useMemo, useState } from "react";
import { Plus } from "lucide-react";
import { Button, Field, Sheet, ViewHeader, areaClass, controlClass } from "@/components/ui";
import { clsx } from "clsx";
import {
  PRESENCE,
  RANKS,
  ROLES,
  formatPower,
  sortedMembers,
  type Member,
  type Presence,
  type Rank,
  type Role,
} from "@/lib/wos/model";
import { newId, useDesk } from "@/lib/wos/store";

type Filter = "all" | "officers" | "captains" | "review";

const FILTERS: { id: Filter; label: string }[] = [
  { id: "all", label: "All" },
  { id: "officers", label: "R4+" },
  { id: "captains", label: "Captains" },
  { id: "review", label: "Review" },
];

const blank = (): Member => ({
  id: newId(),
  name: "",
  rank: "R1",
  power: 20_000_000,
  furnace: 20,
  role: "member",
  presence: "active",
  note: "",
});

export function Roster() {
  const members = useDesk((s) => s.members);
  const addMember = useDesk((s) => s.addMember);
  const updateMember = useDesk((s) => s.updateMember);
  const removeMember = useDesk((s) => s.removeMember);
  const [filter, setFilter] = useState<Filter>("all");
  const [query, setQuery] = useState("");
  const [editing, setEditing] = useState<Member | null>(null);
  const [isNew, setIsNew] = useState(false);

  const list = useMemo(() => {
    const q = query.trim().toLowerCase();
    return sortedMembers(members).filter((m) => {
      if (q && !m.name.toLowerCase().includes(q)) return false;
      if (filter === "officers") return m.rank === "R4" || m.rank === "R5";
      if (filter === "captains") return m.role === "captain";
      if (filter === "review") return m.presence !== "active";
      return true;
    });
  }, [members, filter, query]);

  return (
    <div>
      <ViewHeader
        kicker="Alliance"
        title="Roster"
        action={
          <Button
            variant="primary"
            onClick={() => {
              setIsNew(true);
              setEditing(blank());
            }}
          >
            <Plus size={16} />
            Add
          </Button>
        }
      />
      <p className="mb-3 text-sm text-muted">{members.length} on the list. Ranks, power, and who is drifting.</p>
      <input
        className={controlClass}
        placeholder="Search names"
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        aria-label="Search roster"
      />
      <div className="mt-3 flex gap-2 overflow-x-auto pb-1">
        {FILTERS.map((item) => (
          <button
            key={item.id}
            type="button"
            onClick={() => setFilter(item.id)}
            className={clsx(
              "press h-11 shrink-0 rounded-sm px-3 text-sm font-medium",
              filter === item.id ? "bg-accent text-accent-fg" : "border border-line bg-surface text-muted",
            )}
          >
            {item.label}
          </button>
        ))}
      </div>
      <ul className="mt-3 divide-y divide-line rounded-xl border border-line bg-surface">
        {list.length === 0 ? (
          <li className="p-4 text-sm text-muted">No one matches.</li>
        ) : (
          list.map((m) => (
            <li key={m.id}>
              <button
                type="button"
                onClick={() => {
                  setIsNew(false);
                  setEditing(m);
                }}
                className="flex min-h-14 w-full items-center gap-3 px-3 py-2 text-left"
              >
                <span className="nums w-8 shrink-0 text-xs text-faint">{m.rank}</span>
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-sm font-medium">{m.name}</span>
                  <span className="block truncate text-xs text-muted">
                    {roleLabel(m.role)}
                    {m.note ? ` · ${m.note}` : ""}
                  </span>
                </span>
                <span className="shrink-0 text-right">
                  <span className="nums block text-sm">{formatPower(m.power)}</span>
                  <span className="block text-xs text-faint">
                    FC {m.furnace}
                    {m.presence !== "active" ? ` · ${presenceLabel(m.presence)}` : ""}
                  </span>
                </span>
              </button>
            </li>
          ))
        )}
      </ul>
      <MemberSheet
        member={editing}
        isNew={isNew}
        onClose={() => setEditing(null)}
        onSave={(member) => {
          if (!member.name.trim()) return;
          if (isNew) addMember({ ...member, name: member.name.trim() });
          else updateMember(member.id, { ...member, name: member.name.trim() });
          setEditing(null);
        }}
        onRemove={(id) => {
          removeMember(id);
          setEditing(null);
        }}
      />
    </div>
  );
}

function MemberSheet({
  member,
  isNew,
  onClose,
  onSave,
  onRemove,
}: {
  member: Member | null;
  isNew: boolean;
  onClose: () => void;
  onSave: (member: Member) => void;
  onRemove: (id: string) => void;
}) {
  return (
    <Sheet open={!!member} title={isNew ? "Add member" : "Member"} onClose={onClose}>
      {member ? (
        <MemberForm key={member.id} member={member} isNew={isNew} onSave={onSave} onRemove={onRemove} />
      ) : null}
    </Sheet>
  );
}

function MemberForm({
  member,
  isNew,
  onSave,
  onRemove,
}: {
  member: Member;
  isNew: boolean;
  onSave: (member: Member) => void;
  onRemove: (id: string) => void;
}) {
  const [draft, setDraft] = useState(member);
  const [confirm, setConfirm] = useState(false);
  const [powerText, setPowerText] = useState(() =>
    member.power ? String(Math.round((member.power / 1_000_000) * 10) / 10) : "",
  );
  const patch = (p: Partial<Member>) => setDraft((d) => ({ ...d, ...p }));
  return (
    <>
      <Field label="Name">
        <input className={controlClass} value={draft.name} maxLength={24} onChange={(e) => patch({ name: e.target.value })} />
      </Field>
      <div className="grid grid-cols-2 gap-3">
        <Field label="Rank">
          <select className={controlClass} value={draft.rank} onChange={(e) => patch({ rank: e.target.value as Rank })}>
            {RANKS.map((r) => (
              <option key={r}>{r}</option>
            ))}
          </select>
        </Field>
        <Field label="Role">
          <select className={controlClass} value={draft.role} onChange={(e) => patch({ role: e.target.value as Role })}>
            {ROLES.map((r) => (
              <option key={r.id} value={r.id}>
                {r.label}
              </option>
            ))}
          </select>
        </Field>
      </div>
      <div className="grid grid-cols-2 gap-3">
        <Field label="Power (millions)">
          <input
            className={controlClass}
            inputMode="decimal"
            value={powerText}
            onChange={(e) => {
              const raw = e.target.value;
              if (raw !== "" && !/^\d*\.?\d{0,1}$/.test(raw)) return;
              setPowerText(raw);
              const n = Number(raw);
              if (raw === "" || raw === ".") patch({ power: 0 });
              else if (Number.isFinite(n) && n >= 0) patch({ power: Math.round(n * 1_000_000) });
            }}
          />
        </Field>
        <Field label="Furnace">
          <input
            className={controlClass}
            inputMode="numeric"
            value={draft.furnace}
            onChange={(e) => {
              const n = Number(e.target.value);
              if (Number.isFinite(n)) patch({ furnace: Math.min(30, Math.max(1, Math.round(n))) });
            }}
          />
        </Field>
      </div>
      <Field label="Status">
        <select
          className={controlClass}
          value={draft.presence}
          onChange={(e) => patch({ presence: e.target.value as Presence })}
        >
          {PRESENCE.map((p) => (
            <option key={p.id} value={p.id}>
              {p.label}
            </option>
          ))}
        </select>
      </Field>
      <Field label="Note">
        <textarea className={areaClass} maxLength={160} value={draft.note} onChange={(e) => patch({ note: e.target.value })} />
      </Field>
      <Button variant="primary" className="w-full" disabled={!draft.name.trim()} onClick={() => onSave(draft)}>
        Save
      </Button>
      {!isNew ? (
        confirm ? (
          <div className="mt-2 grid grid-cols-2 gap-2">
            <Button variant="danger" onClick={() => onRemove(draft.id)}>
              Confirm remove
            </Button>
            <Button onClick={() => setConfirm(false)}>Cancel</Button>
          </div>
        ) : (
          <Button variant="quiet" className="mt-2 w-full" onClick={() => setConfirm(true)}>
            Remove from roster
          </Button>
        )
      ) : null}
    </>
  );
}

function roleLabel(role: Role) {
  return ROLES.find((r) => r.id === role)?.label ?? role;
}

function presenceLabel(presence: Presence) {
  return PRESENCE.find((p) => p.id === presence)?.label ?? presence;
}
