export type Rank = "R1" | "R2" | "R3" | "R4" | "R5";
export type Role = "member" | "captain" | "builder" | "farm";
export type Presence = "active" | "away" | "inactive";
export type Rsvp = "in" | "out" | "maybe";
export type Phase = "early" | "growth" | "mature";
export type Tree = "growth" | "territory" | "battle";
export type FortStatus = "open" | "target" | "held" | "enemy";
export type RallyStatus = "forming" | "locked" | "done";
export type EventKind =
  | "bear"
  | "crazy-joe"
  | "mobilization"
  | "fortress"
  | "foundry"
  | "championship"
  | "svs"
  | "showdown"
  | "custom";

export type Member = {
  id: string;
  name: string;
  rank: Rank;
  power: number;
  furnace: number;
  role: Role;
  presence: Presence;
  note: string;
};

export type Lanes = { left: string[]; mid: string[]; right: string[] };

export type AllianceEvent = {
  id: string;
  kind: EventKind;
  title: string;
  startsAt: number;
  note: string;
  rsvp: Record<string, Rsvp>;
  lanes?: Lanes;
};

export type Rally = {
  id: string;
  target: string;
  captainId: string;
  startsAt: number;
  slots: number;
  filled: number;
  hero: string;
  status: RallyStatus;
};

export type TechNode = {
  id: string;
  tree: Tree;
  name: string;
  effect: string;
  level: number;
  max: number;
};

export type Fortress = {
  id: string;
  name: string;
  buff: string;
  status: FortStatus;
};

export type Duty = { id: string; label: string; done: boolean };

export type Alliance = {
  name: string;
  tag: string;
  server: string;
  level: number;
  phase: Phase;
  cap: number;
  donations: number;
  donationGoal: number;
  bearLevel: number;
  ordersNote: string;
};

export type DeskData = {
  alliance: Alliance;
  members: Member[];
  events: AllianceEvent[];
  rallies: Rally[];
  tech: TechNode[];
  forts: Fortress[];
  duties: Duty[];
};

export const RANKS: Rank[] = ["R5", "R4", "R3", "R2", "R1"];
export const ROLES: { id: Role; label: string }[] = [
  { id: "member", label: "Member" },
  { id: "captain", label: "Rally captain" },
  { id: "builder", label: "Builder" },
  { id: "farm", label: "Farm" },
];
export const PRESENCE: { id: Presence; label: string }[] = [
  { id: "active", label: "Active" },
  { id: "away", label: "Away" },
  { id: "inactive", label: "Review" },
];
export const PHASES: { id: Phase; label: string; hint: string }[] = [
  { id: "early", label: "Early", hint: "Levels 1–5. Capacity and help first." },
  { id: "growth", label: "Growth", hint: "Levels 6–8. Cover nodes, then rally size." },
  { id: "mature", label: "Mature", hint: "Levels 9–11. Battle tech and fortresses." },
];

export const KIND_INFO: Record<EventKind, { label: string; cadence: string; rule: string }> = {
  bear: {
    label: "Bear Hunt",
    cadence: "Every 2 server days",
    rule: "R4 or R5 arms the trap. Only the rally starter can kick or disband a bear rally.",
  },
  "crazy-joe": {
    label: "Crazy Joe",
    cadence: "Defense rotation",
    rule: "Unshielded in the hive. Reinforce thinner cities before the first wave.",
  },
  mobilization: {
    label: "Alliance Mobilization",
    cadence: "Weekly, Monday to Sunday",
    rule: "Refresh a weak mission before you claim it. An open slot all day is wasted points.",
  },
  fortress: {
    label: "Fortress Battle",
    cadence: "Fridays, 2-hour window",
    rule: "Hold for 30 minutes to capture. Prefer targets near the HQ.",
  },
  foundry: {
    label: "Foundry Battle",
    cadence: "Registration window",
    rule: "Lock the time slot and the starter list before registration closes.",
  },
  championship: {
    label: "Alliance Championship",
    cadence: "Season rounds",
    rule: "Three lanes. Put online power in mid, and do not leave a lane empty.",
  },
  svs: {
    label: "State vs State",
    cadence: "Season battle",
    rule: "Hospital, shields, and rally captains published before the hit window.",
  },
  showdown: {
    label: "Alliance Showdown",
    cadence: "Weekly scoring",
    rule: "Clear the alliance floor. Small accounts still move the total.",
  },
  custom: {
    label: "Custom",
    cadence: "One-off",
    rule: "",
  },
};

export const TREE_LABEL: Record<Tree, string> = {
  growth: "Growth",
  territory: "Territory",
  battle: "Battle",
};

const PHASE_ORDER: Record<Phase, string[]> = {
  early: ["capacity", "help-count", "help-time", "build-speed"],
  growth: ["banners", "nodes", "rally-size", "warehouse"],
  mature: ["troop-atk", "beast", "troop-def", "march"],
};

const PHASE_WHY: Record<Phase, string> = {
  early: "Capacity and help pay back every day. Battle tech can wait.",
  growth: "Nodes only pay once territory covers them. Finish banners before battle tech.",
  mature: "Growth is online. Attack, beast damage, and march speed move rallies and forts.",
};

export const FORT_STATUS: { id: FortStatus; label: string }[] = [
  { id: "open", label: "Open" },
  { id: "target", label: "Target" },
  { id: "held", label: "Held" },
  { id: "enemy", label: "Enemy" },
];

export const RALLY_STATUS: RallyStatus[] = ["forming", "locked", "done"];

function atHour(base: Date, dayOffset: number, hour: number): number {
  const d = new Date(base);
  d.setDate(d.getDate() + dayOffset);
  d.setHours(hour, 0, 0, 0);
  return d.getTime();
}

function nextWeekday(base: Date, weekday: number, hour: number): number {
  const d = new Date(base);
  let delta = (weekday - d.getDay() + 7) % 7;
  if (delta === 0 && d.getHours() >= hour) delta = 7;
  d.setDate(d.getDate() + delta);
  d.setHours(hour, 0, 0, 0);
  return d.getTime();
}

function startOfWeek(base: Date): Date {
  const d = new Date(base);
  const delta = (d.getDay() + 6) % 7;
  d.setDate(d.getDate() - delta);
  d.setHours(0, 0, 0, 0);
  return d;
}

export function defaultStart(kind: EventKind, now = Date.now()): number {
  const base = new Date(now);
  if (kind === "fortress") return nextWeekday(base, 5, 20);
  if (kind === "mobilization") return startOfWeek(base).getTime();
  if (kind === "championship") return atHour(base, 4, 19);
  return atHour(base, 1, 19);
}

export function initial(now = Date.now()): DeskData {
  const base = new Date(now);
  const bearAt = base.getHours() < 19 ? atHour(base, 0, 19) : atHour(base, 1, 19);
  const members: Member[] = [
    { id: "veyra", name: "Veyra", rank: "R5", power: 162_400_000, furnace: 30, role: "captain", presence: "active", note: "Calls fort targets." },
    { id: "kestrel", name: "Kestrel", rank: "R4", power: 148_100_000, furnace: 30, role: "captain", presence: "active", note: "Bear starter tonight." },
    { id: "ironmoth", name: "Ironmoth", rank: "R4", power: 139_000_000, furnace: 29, role: "captain", presence: "active", note: "Terror rallies." },
    { id: "sable", name: "Sable", rank: "R4", power: 121_600_000, furnace: 28, role: "builder", presence: "active", note: "Banner lead." },
    { id: "holt", name: "Holt", rank: "R3", power: 98_400_000, furnace: 27, role: "captain", presence: "active", note: "" },
    { id: "marrow", name: "Marrow", rank: "R3", power: 91_200_000, furnace: 27, role: "member", presence: "active", note: "" },
    { id: "pike", name: "Pike", rank: "R3", power: 88_000_000, furnace: 26, role: "member", presence: "active", note: "" },
    { id: "nera", name: "Nera", rank: "R2", power: 76_500_000, furnace: 26, role: "member", presence: "active", note: "" },
    { id: "quinn", name: "Quinn", rank: "R2", power: 74_100_000, furnace: 25, role: "member", presence: "away", note: "Travel until Friday." },
    { id: "ashfen", name: "Ashfen", rank: "R2", power: 70_800_000, furnace: 25, role: "farm", presence: "active", note: "Joins bear if online." },
    { id: "bramble", name: "Bramble", rank: "R2", power: 66_400_000, furnace: 24, role: "member", presence: "active", note: "" },
    { id: "joss", name: "Joss", rank: "R2", power: 63_900_000, furnace: 25, role: "member", presence: "active", note: "" },
    { id: "torv", name: "Torv", rank: "R1", power: 58_200_000, furnace: 24, role: "member", presence: "active", note: "" },
    { id: "lumen", name: "Lumen", rank: "R1", power: 54_000_000, furnace: 23, role: "member", presence: "away", note: "" },
    { id: "cade", name: "Cade", rank: "R1", power: 49_700_000, furnace: 22, role: "member", presence: "inactive", note: "Missed the last two bears." },
    { id: "yarrow", name: "Yarrow", rank: "R1", power: 41_300_000, furnace: 21, role: "farm", presence: "inactive", note: "Farm. Shield on SvS day." },
  ];

  const inIds = ["veyra", "kestrel", "ironmoth", "sable", "holt", "marrow", "pike", "nera", "bramble", "joss"];
  const bearRsvp: Record<string, Rsvp> = {};
  for (const id of inIds) bearRsvp[id] = "in";
  bearRsvp.quinn = "out";
  bearRsvp.ashfen = "maybe";

  return {
    alliance: {
      name: "Northwatch",
      tag: "NWT",
      server: "214",
      level: 8,
      phase: "growth",
      cap: 70,
      donations: 18400,
      donationGoal: 25000,
      bearLevel: 6,
      ordersNote: "Hive on the north banners. No solo hits on NAP tags.",
    },
    members,
    events: [
      {
        id: "bear",
        kind: "bear",
        title: "Bear Hunt",
        startsAt: bearAt,
        note: "Online 10 minutes early. First slot is your best expedition skill.",
        rsvp: bearRsvp,
      },
      {
        id: "mob",
        kind: "mobilization",
        title: "Alliance Mobilization",
        startsAt: startOfWeek(base).getTime(),
        note: "Today's focus: training and rallies. Refresh 1-star missions.",
        rsvp: {},
      },
      {
        id: "joe",
        kind: "crazy-joe",
        title: "Crazy Joe",
        startsAt: atHour(base, 2, 18),
        note: "Garrison the sub-FC25 cities first.",
        rsvp: {},
      },
      {
        id: "fort",
        kind: "fortress",
        title: "Fortress Battle",
        startsAt: nextWeekday(base, 5, 20),
        note: "Weapon IV and Expedition III. Hold 30 minutes.",
        rsvp: { veyra: "in", kestrel: "in", ironmoth: "in", sable: "in", holt: "in" },
      },
      {
        id: "champ",
        kind: "championship",
        title: "Alliance Championship",
        startsAt: atHour(base, 4, 19),
        note: "Lane lock an hour before open.",
        rsvp: {
          veyra: "in",
          kestrel: "in",
          ironmoth: "in",
          sable: "in",
          holt: "in",
          marrow: "in",
          pike: "in",
          nera: "maybe",
        },
        lanes: {
          mid: ["veyra", "kestrel"],
          left: ["ironmoth", "holt"],
          right: ["sable"],
        },
      },
    ],
    rallies: [
      {
        id: "rally-bear",
        target: "Bear",
        captainId: "kestrel",
        startsAt: bearAt + 5 * 60 * 1000,
        slots: 8,
        filled: 5,
        hero: "Jessie, first slot",
        status: "forming",
      },
      {
        id: "rally-terror",
        target: "Polar Terror 7",
        captainId: "ironmoth",
        startsAt: atHour(base, 0, Math.min(23, base.getHours() + 2)),
        slots: 8,
        filled: 8,
        hero: "Bahiti, first slot",
        status: "locked",
      },
    ],
    tech: [
      { id: "capacity", tree: "growth", name: "Member capacity", effect: "Raises the roster cap.", level: 4, max: 5 },
      { id: "help-count", tree: "growth", name: "Help requests", effect: "More helps on each timer.", level: 5, max: 5 },
      { id: "help-time", tree: "growth", name: "Help duration", effect: "Each help cuts more time.", level: 3, max: 5 },
      { id: "build-speed", tree: "growth", name: "Construction speed", effect: "Faster alliance builds.", level: 4, max: 8 },
      { id: "research-speed", tree: "growth", name: "Research speed", effect: "Faster personal research for members.", level: 3, max: 8 },
      { id: "banners", tree: "territory", name: "Banner count", effect: "More banners, wider hive.", level: 4, max: 5 },
      { id: "nodes", tree: "territory", name: "Node output", effect: "Territory nodes feed the warehouse.", level: 2, max: 6 },
      { id: "warehouse", tree: "territory", name: "Warehouse", effect: "Larger alliance stockpile.", level: 2, max: 5 },
      { id: "expand", tree: "territory", name: "Expansion speed", effect: "Banners finish faster.", level: 1, max: 5 },
      { id: "rally-size", tree: "battle", name: "Rally slots", effect: "More marches in each rally.", level: 3, max: 6 },
      { id: "troop-atk", tree: "battle", name: "Troop attack", effect: "Alliance attack bonus.", level: 2, max: 10 },
      { id: "troop-def", tree: "battle", name: "Troop defense", effect: "Alliance defense bonus.", level: 2, max: 10 },
      { id: "beast", tree: "battle", name: "Beast damage", effect: "Rally damage against terrors and the bear.", level: 1, max: 8 },
      { id: "march", tree: "battle", name: "March speed", effect: "Faster marches for members.", level: 2, max: 8 },
    ],
    forts: [
      { id: "con1", name: "Construction I", buff: "Construction speed +5%", status: "open" },
      { id: "con3", name: "Construction III", buff: "Construction speed +8%", status: "open" },
      { id: "def2", name: "Defense II", buff: "Troop defense +5%", status: "open" },
      { id: "def4", name: "Defense IV", buff: "Troop defense +8%", status: "enemy" },
      { id: "tech1", name: "Tech I", buff: "Research speed +5%", status: "held" },
      { id: "tech3", name: "Tech III", buff: "Research speed +8%", status: "open" },
      { id: "wep2", name: "Weapon II", buff: "Troop attack +5%", status: "open" },
      { id: "wep4", name: "Weapon IV", buff: "Troop attack +8%", status: "target" },
      { id: "gath", name: "Gathering I", buff: "Gathering speed +5%", status: "held" },
      { id: "prod", name: "Production I", buff: "Production speed +5%", status: "open" },
      { id: "train", name: "Training II", buff: "Training speed +5%", status: "open" },
      { id: "exp", name: "Expedition III", buff: "March speed +15%", status: "target" },
    ],
    duties: [
      { id: "bear-post", label: "Bear time posted in chat", done: false },
      { id: "mob-focus", label: "Mobilization focus announced", done: true },
      { id: "tech-mark", label: "Priority tech marked, started if the bar is full", done: false },
      { id: "inactive", label: "Inactive names reviewed", done: false },
      { id: "fort-reg", label: "Fortress targets registered", done: true },
      { id: "captains", label: "Rally captain list is current", done: false },
    ],
  };
}

export function formatPower(n: number): string {
  if (!Number.isFinite(n) || n <= 0) return "0";
  if (n >= 1_000_000) {
    const m = n / 1_000_000;
    return `${m >= 100 ? m.toFixed(0) : m.toFixed(1)}M`;
  }
  if (n >= 1_000) return `${Math.round(n / 1_000)}K`;
  return String(Math.round(n));
}

export function formatWhen(ts: number, now = Date.now()): string {
  const d = new Date(ts);
  const start = new Date(now);
  start.setHours(0, 0, 0, 0);
  const day = new Date(ts);
  day.setHours(0, 0, 0, 0);
  const diff = Math.round((day.getTime() - start.getTime()) / 86_400_000);
  const hm = d.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
  if (diff === 0) return `Today ${hm}`;
  if (diff === 1) return `Tomorrow ${hm}`;
  if (diff === -1) return `Yesterday ${hm}`;
  if (diff > 1 && diff < 7) {
    return `${d.toLocaleDateString([], { weekday: "short" })} ${hm}`;
  }
  return `${d.toLocaleDateString([], { month: "short", day: "numeric" })} ${hm}`;
}

export function formatCountdown(ts: number, now: number): string {
  const delta = ts - now;
  const abs = Math.abs(delta);
  const minutes = Math.max(0, Math.round(abs / 60_000));
  const h = Math.floor(minutes / 60);
  const m = minutes % 60;
  const body = h > 48 ? `${Math.round(h / 24)}d` : h > 0 ? `${h}h ${m}m` : `${m}m`;
  if (Math.abs(delta) < 30_000) return "now";
  return delta >= 0 ? `in ${body}` : `${body} ago`;
}

export function formatStamp(now = Date.now()): string {
  return new Date(now).toLocaleDateString([], {
    weekday: "short",
    month: "short",
    day: "numeric",
  });
}

export function toLocalInput(ts: number): string {
  const d = new Date(ts);
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

export function fromLocalInput(value: string): number {
  const t = new Date(value).getTime();
  return Number.isFinite(t) ? t : Date.now();
}

export function sortedMembers(members: Member[]): Member[] {
  const rank: Record<Rank, number> = { R5: 0, R4: 1, R3: 2, R2: 3, R1: 4 };
  return [...members].sort((a, b) => rank[a.rank] - rank[b.rank] || b.power - a.power);
}

export function memberById(members: Member[], id: string): Member | undefined {
  return members.find((m) => m.id === id);
}

export function memberName(members: Member[], id: string): string {
  return memberById(members, id)?.name ?? "Unassigned";
}

export function nextEvent(events: AllianceEvent[], now: number): AllianceEvent | null {
  const sorted = [...events].sort((a, b) => a.startsAt - b.startsAt);
  return sorted.find((e) => e.startsAt >= now - 30 * 60_000) ?? sorted[0] ?? null;
}

export function rsvpCounts(event: AllianceEvent, members: Member[]) {
  let inn = 0;
  let out = 0;
  let maybe = 0;
  let silent = 0;
  for (const m of members) {
    const v = event.rsvp[m.id];
    if (v === "in") inn += 1;
    else if (v === "out") out += 1;
    else if (v === "maybe") maybe += 1;
    else silent += 1;
  }
  return { inn, out, maybe, silent };
}

export function namesFor(event: AllianceEvent, members: Member[], value: Rsvp | "silent"): string[] {
  return sortedMembers(members)
    .filter((m) => (value === "silent" ? !event.rsvp[m.id] : event.rsvp[m.id] === value))
    .map((m) => m.name);
}

export function recommendation(tech: TechNode[], phase: Phase): { node: TechNode | null; why: string } {
  for (const id of PHASE_ORDER[phase]) {
    const node = tech.find((t) => t.id === id);
    if (node && node.level < node.max) return { node, why: PHASE_WHY[phase] };
  }
  const fallback = tech.find((t) => t.level < t.max) ?? null;
  return {
    node: fallback,
    why: fallback ? "Marked priorities for this phase are done. This is the next open node." : "Every tracked node is finished.",
  };
}

export function treeProgress(tech: TechNode[], tree: Tree) {
  const list = tech.filter((t) => t.tree === tree);
  const cur = list.reduce((sum, n) => sum + n.level, 0);
  const max = list.reduce((sum, n) => sum + n.max, 0);
  return { cur, max, pct: max ? Math.round((cur / max) * 100) : 0 };
}

export function emptyLanes(): Lanes {
  return { left: [], mid: [], right: [] };
}

export function cycleLane(lanes: Lanes | undefined, memberId: string): Lanes {
  const current = lanes ?? emptyLanes();
  const cleaned: Lanes = {
    left: current.left.filter((id) => id !== memberId),
    mid: current.mid.filter((id) => id !== memberId),
    right: current.right.filter((id) => id !== memberId),
  };
  const spot = current.mid.includes(memberId)
    ? "left"
    : current.left.includes(memberId)
      ? "right"
      : current.right.includes(memberId)
        ? null
        : "mid";
  if (spot) cleaned[spot].push(memberId);
  return cleaned;
}

export function balanceLanes(event: AllianceEvent, members: Member[]): Lanes {
  const lanes = emptyLanes();
  const ranked = sortedMembers(members)
    .filter((m) => event.rsvp[m.id] === "in")
    .sort((a, b) => b.power - a.power);
  const order: Array<keyof Lanes> = ["mid", "left", "right", "right", "left", "mid"];
  ranked.forEach((m, i) => {
    lanes[order[i % order.length]!]!.push(m.id);
  });
  return lanes;
}

export type PingKind = "full" | "bear" | "silent" | "donate" | "forts" | "lanes";

function join(names: string[]): string {
  return names.length ? names.join(", ") : "none";
}

export function buildPing(kind: PingKind, data: DeskData, now = Date.now()): { title: string; body: string } {
  const { alliance, members, events, rallies, tech, forts } = data;
  const head = `[${alliance.tag}] ${alliance.name}`;
  const upcoming = nextEvent(events, now);
  const rec = recommendation(tech, alliance.phase);
  const targets = forts.filter((f) => f.status === "target");
  const held = forts.filter((f) => f.status === "held");
  const review = members.filter((m) => m.presence === "inactive");
  const bear = events.find((e) => e.kind === "bear") ?? upcoming;
  const champ = events.find((e) => e.kind === "championship");

  if (kind === "bear") {
    if (!bear) {
      return { title: "Bear call", body: `${head}\nNo bear on the board. Add one under Ops.` };
    }
    const c = rsvpCounts(bear, members);
    return {
      title: "Bear call",
      body: [
        `${head} — ${bear.title}`,
        `${formatWhen(bear.startsAt, now)} (${formatCountdown(bear.startsAt, now)})`,
        `Trap level ${alliance.bearLevel}. Online 10 minutes early.`,
        `In (${c.inn}): ${join(namesFor(bear, members, "in"))}`,
        `Out: ${join(namesFor(bear, members, "out"))}`,
        `Maybe: ${join(namesFor(bear, members, "maybe"))}`,
        `No reply: ${join(namesFor(bear, members, "silent"))}`,
        KIND_INFO.bear.rule,
        bear.note,
      ]
        .filter(Boolean)
        .join("\n"),
    };
  }

  if (kind === "silent") {
    if (!upcoming) {
      return { title: "Silent nudge", body: `${head}\nNothing scheduled to chase.` };
    }
    return {
      title: "Silent nudge",
      body: [
        `${head} — need a yes or no`,
        `${upcoming.title} · ${formatWhen(upcoming.startsAt, now)}`,
        join(namesFor(upcoming, members, "silent")),
        "Reply in alliance chat. Silence gets read as inactive.",
      ].join("\n"),
    };
  }

  if (kind === "donate") {
    const node = rec.node;
    return {
      title: "Donate ping",
      body: [
        `${head} — tech donations`,
        node ? `Next: ${node.name} ${node.level}/${node.max}. ${node.effect}` : "No open research.",
        `Today ${alliance.donations.toLocaleString()} / ${alliance.donationGoal.toLocaleString()}.`,
        "Resources before gems. Do not start a side tech.",
        rec.why,
      ].join("\n"),
    };
  }

  if (kind === "forts") {
    return {
      title: "Fortress plan",
      body: [
        `${head} — fortresses`,
        targets.length
          ? `Targets: ${targets.map((f) => `${f.name} (${f.buff})`).join("; ")}`
          : "No targets marked.",
        held.length ? `Already held: ${held.map((f) => f.name).join(", ")}` : "Nothing held.",
        KIND_INFO.fortress.rule,
      ].join("\n"),
    };
  }

  if (kind === "lanes") {
    if (!champ) {
      return { title: "Lane card", body: `${head}\nNo championship on the board.` };
    }
    const lanes = champ.lanes ?? emptyLanes();
    const line = (key: keyof Lanes) =>
      `${key[0]!.toUpperCase()}${key.slice(1)}: ${join(lanes[key].map((id) => memberName(members, id)))}`;
    const assigned = new Set([...lanes.left, ...lanes.mid, ...lanes.right]);
    const loose = namesFor(champ, members, "in").filter((name) => {
      const m = members.find((x) => x.name === name);
      return m ? !assigned.has(m.id) : false;
    });
    return {
      title: "Lane card",
      body: [
        `${head} — ${champ.title}`,
        formatWhen(champ.startsAt, now),
        line("mid"),
        line("left"),
        line("right"),
        `In, no lane: ${join(loose)}`,
        KIND_INFO.championship.rule,
      ].join("\n"),
    };
  }

  const lines: string[] = [
    `${head} · State ${alliance.server} · Lv.${alliance.level}`,
    `Orders · ${formatStamp(now)}`,
    "",
  ];
  if (upcoming) {
    const c = rsvpCounts(upcoming, members);
    lines.push(
      `NEXT — ${upcoming.title}`,
      `${formatWhen(upcoming.startsAt, now)} (${formatCountdown(upcoming.startsAt, now)})`,
      KIND_INFO[upcoming.kind].rule,
      upcoming.note,
      `In ${c.inn} · Out ${c.out} · Maybe ${c.maybe} · Silent ${c.silent}`,
      c.silent ? `No reply: ${join(namesFor(upcoming, members, "silent"))}` : "Everyone has answered.",
      "",
    );
  }
  const openRallies = rallies.filter((r) => r.status !== "done");
  if (openRallies.length) {
    lines.push("RALLIES");
    for (const r of openRallies) {
      lines.push(
        `${r.target} · ${memberName(members, r.captainId)} · ${r.status} · ${r.filled}/${r.slots} · ${formatWhen(r.startsAt, now)}`,
        r.hero ? `First slot: ${r.hero}` : "Set the first-slot hero.",
      );
    }
    lines.push("");
  }
  if (rec.node) {
    lines.push(
      "RESEARCH",
      `${rec.node.name} ${rec.node.level}/${rec.node.max}`,
      `Donations ${alliance.donations.toLocaleString()} / ${alliance.donationGoal.toLocaleString()} today.`,
      "",
    );
  }
  if (targets.length) {
    lines.push("FORTRESS TARGETS", targets.map((f) => `${f.name} — ${f.buff}`).join("\n"), "");
  }
  if (review.length) {
    lines.push(
      "ROSTER REVIEW",
      review.map((m) => `${m.name}${m.note ? ` — ${m.note}` : ""}`).join("\n"),
      "",
    );
  }
  if (alliance.ordersNote.trim()) {
    lines.push("NOTE", alliance.ordersNote.trim());
  }
  return { title: "Full orders", body: lines.join("\n").trim() };
}

function isRecord(v: unknown): v is Record<string, unknown> {
  return !!v && typeof v === "object" && !Array.isArray(v);
}

export function normalizeDesk(raw: unknown): DeskData | null {
  if (!isRecord(raw) || !isRecord(raw.alliance) || !Array.isArray(raw.members)) return null;
  const base = initial();
  const alliance = { ...base.alliance };
  const src = raw.alliance;
  if (typeof src.name === "string" && src.name.trim()) alliance.name = src.name.trim().slice(0, 40);
  if (typeof src.tag === "string") alliance.tag = src.tag.trim().slice(0, 6) || alliance.tag;
  if (typeof src.server === "string") alliance.server = src.server.trim().slice(0, 12);
  if (typeof src.level === "number") alliance.level = clamp(src.level, 1, 11);
  if (src.phase === "early" || src.phase === "growth" || src.phase === "mature") alliance.phase = src.phase;
  if (typeof src.cap === "number") alliance.cap = clamp(src.cap, 10, 120);
  if (typeof src.donations === "number") alliance.donations = Math.max(0, Math.round(src.donations));
  if (typeof src.donationGoal === "number") alliance.donationGoal = Math.max(0, Math.round(src.donationGoal));
  if (typeof src.bearLevel === "number") alliance.bearLevel = clamp(src.bearLevel, 1, 20);
  if (typeof src.ordersNote === "string") alliance.ordersNote = src.ordersNote.slice(0, 400);

  const members = raw.members.filter(isMember);
  if (!members.length) return null;
  return {
    alliance,
    members,
    events: Array.isArray(raw.events) ? raw.events.filter(isEvent) : [],
    rallies: Array.isArray(raw.rallies) ? raw.rallies.filter(isRally) : [],
    tech: Array.isArray(raw.tech) && raw.tech.filter(isTech).length ? raw.tech.filter(isTech) : base.tech,
    forts: Array.isArray(raw.forts) && raw.forts.filter(isFort).length ? raw.forts.filter(isFort) : base.forts,
    duties: Array.isArray(raw.duties) && raw.duties.filter(isDuty).length ? raw.duties.filter(isDuty) : base.duties,
  };
}

function clamp(n: number, min: number, max: number) {
  return Math.min(max, Math.max(min, Math.round(n)));
}

function isMember(v: unknown): v is Member {
  if (!isRecord(v) || typeof v.id !== "string" || typeof v.name !== "string") return false;
  const ranks: Rank[] = ["R1", "R2", "R3", "R4", "R5"];
  const roles: Role[] = ["member", "captain", "builder", "farm"];
  const presence: Presence[] = ["active", "away", "inactive"];
  return (
    ranks.includes(v.rank as Rank) &&
    roles.includes(v.role as Role) &&
    presence.includes(v.presence as Presence) &&
    typeof v.power === "number" &&
    typeof v.furnace === "number"
  );
}

function isEvent(v: unknown): v is AllianceEvent {
  if (!isRecord(v) || typeof v.id !== "string" || typeof v.title !== "string") return false;
  return typeof v.startsAt === "number" && typeof v.kind === "string" && isRecord(v.rsvp);
}

function isRally(v: unknown): v is Rally {
  if (!isRecord(v) || typeof v.id !== "string" || typeof v.target !== "string") return false;
  return typeof v.captainId === "string" && typeof v.startsAt === "number";
}

function isTech(v: unknown): v is TechNode {
  if (!isRecord(v) || typeof v.id !== "string" || typeof v.name !== "string") return false;
  return typeof v.level === "number" && typeof v.max === "number" && typeof v.tree === "string";
}

function isFort(v: unknown): v is Fortress {
  return isRecord(v) && typeof v.id === "string" && typeof v.name === "string" && typeof v.status === "string";
}

function isDuty(v: unknown): v is Duty {
  return isRecord(v) && typeof v.id === "string" && typeof v.label === "string" && typeof v.done === "boolean";
}
