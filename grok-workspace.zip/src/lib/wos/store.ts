import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";
import {
  balanceLanes,
  cycleLane,
  emptyLanes,
  initial,
  normalizeDesk,
  type Alliance,
  type AllianceEvent,
  type DeskData,
  type FortStatus,
  type Member,
  type Rally,
  type Rsvp,
} from "@/lib/wos/model";

const FORT_ORDER: FortStatus[] = ["open", "target", "held", "enemy"];

type Actions = {
  updateAlliance: (patch: Partial<Alliance>) => void;
  addMember: (member: Member) => void;
  updateMember: (id: string, patch: Partial<Member>) => void;
  removeMember: (id: string) => void;
  addEvent: (event: AllianceEvent) => void;
  updateEvent: (id: string, patch: Partial<AllianceEvent>) => void;
  removeEvent: (id: string) => void;
  setRsvp: (eventId: string, memberId: string, value: Rsvp) => void;
  cycleMemberLane: (eventId: string, memberId: string) => void;
  autoLanes: (eventId: string) => void;
  addRally: (rally: Rally) => void;
  updateRally: (id: string, patch: Partial<Rally>) => void;
  removeRally: (id: string) => void;
  setTechLevel: (id: string, level: number) => void;
  cycleFort: (id: string) => void;
  toggleDuty: (id: string) => void;
  replaceAll: (data: DeskData) => void;
  resetDemo: () => void;
};

const memory = {
  getItem: () => null,
  setItem: () => {},
  removeItem: () => {},
};

export const useDesk = create<DeskData & Actions>()(
  persist(
    (set) => ({
      ...initial(),
      updateAlliance: (patch) => set((s) => ({ alliance: { ...s.alliance, ...patch } })),
      addMember: (member) => set((s) => ({ members: [...s.members, member] })),
      updateMember: (id, patch) =>
        set((s) => ({
          members: s.members.map((m) => (m.id === id ? { ...m, ...patch } : m)),
        })),
      removeMember: (id) =>
        set((s) => ({
          members: s.members.filter((m) => m.id !== id),
          events: s.events.map((e) => {
            const rsvp = { ...e.rsvp };
            delete rsvp[id];
            const lanes = e.lanes
              ? {
                  left: e.lanes.left.filter((x) => x !== id),
                  mid: e.lanes.mid.filter((x) => x !== id),
                  right: e.lanes.right.filter((x) => x !== id),
                }
              : e.lanes;
            return { ...e, rsvp, lanes };
          }),
          rallies: s.rallies.map((r) => (r.captainId === id ? { ...r, captainId: s.members.find((m) => m.id !== id)?.id ?? "" } : r)),
        })),
      addEvent: (event) => set((s) => ({ events: [...s.events, event] })),
      updateEvent: (id, patch) =>
        set((s) => ({
          events: s.events.map((e) => (e.id === id ? { ...e, ...patch } : e)),
        })),
      removeEvent: (id) => set((s) => ({ events: s.events.filter((e) => e.id !== id) })),
      setRsvp: (eventId, memberId, value) =>
        set((s) => ({
          events: s.events.map((e) => {
            if (e.id !== eventId) return e;
            const rsvp = { ...e.rsvp };
            if (rsvp[memberId] === value) delete rsvp[memberId];
            else rsvp[memberId] = value;
            return { ...e, rsvp };
          }),
        })),
      cycleMemberLane: (eventId, memberId) =>
        set((s) => ({
          events: s.events.map((e) =>
            e.id === eventId ? { ...e, lanes: cycleLane(e.lanes ?? emptyLanes(), memberId) } : e,
          ),
        })),
      autoLanes: (eventId) =>
        set((s) => ({
          events: s.events.map((e) => (e.id === eventId ? { ...e, lanes: balanceLanes(e, s.members) } : e)),
        })),
      addRally: (rally) => set((s) => ({ rallies: [...s.rallies, rally] })),
      updateRally: (id, patch) =>
        set((s) => ({
          rallies: s.rallies.map((r) => (r.id === id ? { ...r, ...patch } : r)),
        })),
      removeRally: (id) => set((s) => ({ rallies: s.rallies.filter((r) => r.id !== id) })),
      setTechLevel: (id, level) =>
        set((s) => ({
          tech: s.tech.map((t) =>
            t.id === id ? { ...t, level: Math.max(0, Math.min(t.max, Math.round(level))) } : t,
          ),
        })),
      cycleFort: (id) =>
        set((s) => ({
          forts: s.forts.map((f) => {
            if (f.id !== id) return f;
            const i = FORT_ORDER.indexOf(f.status);
            const status = FORT_ORDER[(i + 1) % FORT_ORDER.length] ?? "open";
            return { ...f, status };
          }),
        })),
      toggleDuty: (id) =>
        set((s) => ({
          duties: s.duties.map((d) => (d.id === id ? { ...d, done: !d.done } : d)),
        })),
      replaceAll: (data) => set(() => data),
      resetDemo: () => set(() => initial()),
    }),
    {
      name: "frostline-desk-v1",
      skipHydration: true,
      storage: createJSONStorage(() => (typeof window === "undefined" ? memory : localStorage)),
      merge: (persisted, current) => {
        const data = normalizeDesk(persisted);
        if (!data) return current;
        return { ...current, ...data };
      },
    },
  ),
);

export function newId(): string {
  return crypto.randomUUID();
}
